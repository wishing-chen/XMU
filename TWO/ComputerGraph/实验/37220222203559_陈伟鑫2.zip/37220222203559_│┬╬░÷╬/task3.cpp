#include <GL/glut.h>
#include <cmath>
#define M_PI 3.14159265359

GLfloat beta = 0;

GLfloat eyeX = 0.0f;
GLfloat eyeY = 0.0f;
GLfloat eyeZ = 3.0f;

GLfloat gazeX = 0.0f;
GLfloat gazeY = 0.0f;
GLfloat gazeZ = 0.0f;

bool movFlag = true;

//����task2�Ĵ���
void init(void)
{
    glClearColor(0.0, 0.0, 0.0, 0.0);
    glColor3f(1.0, 0.0, 0.0);

    glShadeModel(GL_SMOOTH);
    glEnable(GL_DEPTH_TEST);
}

void drawSphere(float r) {
    float phi, theta;
    float x0, y0, z0;
    float x1, y1, z1;
    float x2, y2, z2;

    //ʹ��������İ취 �ο������ϵİ취
    for (int i = 0; i <= 30; ++i) {
        phi = M_PI / 30 * i;      
        glBegin(GL_LINE_LOOP);
        for (int j = 0; j <= 30; ++j) {
            theta = 2.0 * M_PI / 30 * j;
            x0 = r * sin(phi) * cos(theta);
            y0 = r * sin(phi) * sin(theta);
            z0 = r * cos(phi);
            glVertex3f(x0, y0, z0);

            x1 = r * sin(phi) * cos(theta + 2.0 * M_PI / 30);
            y1 = r * sin(phi) * sin(theta + 2.0 * M_PI / 30);
            z1 = r * cos(phi);
            glVertex3f(x1, y1, z1);

            if (i != 30) {
                x2 = r * sin(phi + M_PI / 30) * cos(theta);
                y2 = r * sin(phi + M_PI / 30) * sin(theta);
                z2 = r * cos(phi + M_PI / 30);
                glVertex3f(x2, y2, z2);
            }
        }
        glEnd();
    }
}

//����task2�Ĵ���
void display() {
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    glLoadIdentity();

    gluLookAt(eyeX, eyeY, eyeZ, gazeX, gazeY, gazeZ, 0.0, 1.0, 0.0);
    glColor3f(0.0, 0.0, 1.0);
    glRotatef(beta,0 , 0, 1);
    drawSphere(1.0);

    glutSwapBuffers();
}
//����task2�Ĵ���
void reshape(int w, int h)
{
    glViewport(0, 0, (GLsizei)w, (GLsizei)h);

    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluPerspective(45.0, (GLfloat)w / (GLfloat)h, 0.1, 100.0);

    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
    gluLookAt(eyeX, eyeY, eyeZ, gazeX, gazeY, gazeZ, 0.0, 1.0, 0.0);
}
//����task2�Ĵ���
void idlefunc()
{
    beta += 0.05;
    if (beta > 360) beta -= 360;
    glutPostRedisplay();
}
//����task2�Ĵ���
void keyboard(unsigned char key, int x, int y)
{
    switch (key) {
    case 'A':
    case 'a':
        if (movFlag) {
            eyeX += 0.1f;
            gazeX += 0.1f;
        }
        break;
    case 'W':
    case 'w':
        if (movFlag) eyeZ -= 0.1f;
        break;
    case 'S':
    case 's':
        if (movFlag) eyeZ += 0.1f;
        break;
    case 'D':
    case 'd':
        if (movFlag) {
            eyeX -= 0.1f;
            gazeX -= 0.1f;
        }
        break;
    case 'E':
    case 'e':
        if (movFlag) {
            eyeY += 0.1f;
            gazeY += 0.1f;
        }
        break;
    case 'Q':
    case 'q':
        if (movFlag) {
            eyeY -= 0.1f;
            gazeY -= 0.1f;
        }
        break;
    case'L':
    case'l':
        if (movFlag) movFlag = false;
        else movFlag = true;
        break;
    case 27:
        exit(0);
        break;
    }
    glutPostRedisplay();
}
//����task2�Ĵ���
void mouse(int x, int y)
{
    if (movFlag) {
        gazeX = (x - glutGet(GLUT_WINDOW_WIDTH) / 2) * 0.01;
        gazeY = (glutGet(GLUT_WINDOW_HEIGHT) / 2 - y) * 0.01;
    }

    glutPostRedisplay();
}
//����task2�Ĵ���
int main(int argc, char** argv) {
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
    glutInitWindowSize(500, 500);
    glutInitWindowPosition(100, 100);
    glutCreateWindow(argv[0]);
    init();
    glutDisplayFunc(display);
    glutReshapeFunc(reshape);
    glutIdleFunc(idlefunc);
    glutKeyboardFunc(keyboard);
    glutPassiveMotionFunc(mouse);
    glutMainLoop();

    return 0;
}
