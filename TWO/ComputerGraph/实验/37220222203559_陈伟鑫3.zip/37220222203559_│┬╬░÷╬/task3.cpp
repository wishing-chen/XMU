#include <GL/glut.h>
#include <math.h>

#define DEG_TO_RAD 0.017453

const GLfloat RR = 2.0; //camera rad
GLfloat beta = 0;

GLfloat eyeX = 0.0f;
GLfloat eyeY = 0.0f;
GLfloat eyeZ = 10.0f;

GLfloat gazeX = 0.0f;
GLfloat gazeY = 0.0f;
GLfloat gazeZ = 0.0f;
GLfloat light_position[] = { 1.0, 1.0, 1.0, 0.0 }; 
GLfloat light_diffuse[] = { 1.0, 1.0, 1.0, 1.0 }; 
GLfloat color_light_diffuse[] = { 0.0, 1.0, 0.0, 1.0 };
GLfloat material_ambient[] = { 0.2, 0.2, 0.2, 1.0 }; 
GLfloat material_diffuse[] = { 0.8, 0.8, 0.8, 1.0 };
GLfloat material_specular[] = { 1.0, 1.0, 1.0, 1.0 }; 
GLfloat material_shininess[] = { 50.0 }; 
bool movFlag = true;

void init(void)
{
    glClearColor(0.0, 0.0, 0.0, 0.0);
    glColor3f(1.0, 0.0, 0.0);

    //��������ѡһ������Ч��
    glShadeModel(GL_SMOOTH);    
    //glShadeModel(GL_FLAT);

    glEnable(GL_LIGHTING);
    glEnable(GL_LIGHT0);
    glEnable(GL_DEPTH_TEST);

    glLightfv(GL_LIGHT0, GL_POSITION, light_position);
    glLightfv(GL_LIGHT0, GL_DIFFUSE, light_diffuse);

    glLightfv(GL_LIGHT1, GL_POSITION, light_position);
    glLightfv(GL_LIGHT1, GL_DIFFUSE, color_light_diffuse);

    glMaterialfv(GL_FRONT, GL_AMBIENT, material_ambient);
    glMaterialfv(GL_FRONT, GL_DIFFUSE, material_diffuse);
    glMaterialfv(GL_FRONT, GL_SPECULAR, material_specular);
    glMaterialfv(GL_FRONT, GL_SHININESS, material_shininess);
}

void display(void)
{
    // glClear(GL_COLOR_BUFFER_BIT);
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();

    gluLookAt(eyeX, eyeY, eyeZ, gazeX, gazeY, gazeZ, 0.0, 1.0, 0.0);

    glRotatef(beta, 1, 1,1);

    //���������������Σ������иĳɻ���������  Done
    glBegin(GL_QUADS);
    // face A ��
    glColor3f(1.0, 0.0, 0.0);
    glVertex3f(-1, 1, -1);
    glVertex3f(-1, 1, 1);
    glVertex3f(1, 1, 1);
    glVertex3f(1, 1, -1);
    glEnd();
    // face B ��
    glBegin(GL_QUADS);
    glColor3f(1, 1, 0);
    glVertex3f(1, 1, -1);
    glVertex3f(1, 1, 1);
    glVertex3f(1, -1, 1);
    glVertex3f(1, -1, -1);
    glEnd();
    // face C ǰ
    glBegin(GL_QUADS);
    glColor3f(0, 1, 0);
    glVertex3f(-1, 1, 1);
    glVertex3f(1, 1, 1);
    glVertex3f(1, -1, 1);
    glVertex3f(-1, -1, 1);
    glEnd();
    // face D ��
    glBegin(GL_QUADS);
    glColor3f(0, 0, 1);
    glVertex3f(-1, 1, 1);
    glVertex3f(-1, -1, 1);
    glVertex3f(-1, -1, -1);
    glVertex3f(-1, 1, -1);
    glEnd();
    // face E ��
    glBegin(GL_QUADS);
    glColor3f(1, 0, 1);
    glVertex3f(-1, -1, -1);
    glVertex3f(-1, -1, 1);
    glVertex3f(1, -1, 1);
    glVertex3f(1, -1, -1);
    glEnd();
    //face F ��
    glBegin(GL_QUADS);
    glColor3f(1, 1, 1);
    glVertex3f(-1, -1, -1);
    glVertex3f(1, -1, -1);
    glVertex3f(1, 1, -1);
    glVertex3f(-1, 1, -1);
    glEnd();

    //glFlush(); /* clear buffers */
    glutSwapBuffers();
}

void reshape(int w, int h)
{
    glViewport(0, 0, (GLsizei)w, (GLsizei)h);

    //��������������ͶӰ����
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    //���������ѡһ������Ч��
    //glOrtho(-1.0, 1.0, -1.0, 1.0, -1.0, 1.0);
    //glOrtho(-4.0, 4.0, -4.0, 4.0, -10.0, 10.0);
    //glFrustum(-1.0, 1.0, -1.0, 1.0, 0.3, 10.0);
    gluPerspective(45.0, (GLfloat)w / (GLfloat)h, 0.1, 100.0);

    //�����������������������Է�λ
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
    gluLookAt(eyeX, eyeY, eyeZ, gazeX, gazeY, gazeZ, 0.0, 1.0, 0.0);
}

void idlefunc()
{
    beta += 0.03;
    if (beta > 360) beta -= 360;
    glutPostRedisplay();
}

void keyboard(unsigned char key, int x, int y)
{
    switch (key) {
    case 'A':
    case 'a':
        if (movFlag) {
            eyeX += 0.1f;
            gazeX += 0.1f;}
        break;
    case 'W':
    case 'w':
        if (movFlag) eyeZ -= 0.1f;
        break;
    case 'S':
    case 's':
        if (movFlag) eyeZ += 0.1f;
        break;
    case 'D':
    case 'd':
        if (movFlag){
            eyeX -= 0.1f;
            gazeX -= 0.1f;}
        break;
    case 'E':
    case 'e':
        if (movFlag){
            eyeY += 0.1f;
            gazeY += 0.1f;}
        break;
    case 'Q':
    case 'q':
        if (movFlag){
            eyeY -= 0.1f;
            gazeY -= 0.1f;}
        break;
    case'L':
    case'l':
        if (movFlag) movFlag = false;
        else movFlag = true;
        break;
    case'B':
    case'b':
        material_ambient[0] = 0.329412; material_ambient[1] = 0.223529; material_ambient[2] = 0.027451; material_ambient[3] = 1.000000;
        material_diffuse[0] = 0.780392; material_diffuse[1] = 0.568627; material_diffuse[2] = 0.113725; material_diffuse[3] = 1.000000;
        material_specular[0] = 0.992157; material_specular[1] = 0.941176; material_specular[2] = 0.807843; material_specular[3] = 1.000000;
        material_shininess[0] = 27.897400;
        glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT, material_ambient);
        glMaterialfv(GL_FRONT_AND_BACK, GL_DIFFUSE, material_diffuse);
        glMaterialfv(GL_FRONT_AND_BACK, GL_SPECULAR, material_specular);
        glMaterialfv(GL_FRONT_AND_BACK, GL_SHININESS, material_shininess);
        break;
    case'N':
    case'n':
        material_ambient[0] = 0.2; material_ambient[1] = 0.0; material_ambient[2] = 0.0; material_ambient[3] = 1.000000;
        material_diffuse[0] = 0.8; material_diffuse[1] = 0.0; material_diffuse[2] = 0.0; material_diffuse[3] = 1.000000;
        material_specular[0] = 1.0; material_specular[1] = 0.8; material_specular[2] = 0.8; material_specular[3] = 1.000000;
        material_shininess[0] = 75;
        glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT, material_ambient);
        glMaterialfv(GL_FRONT_AND_BACK, GL_DIFFUSE, material_diffuse);
        glMaterialfv(GL_FRONT_AND_BACK, GL_SPECULAR, material_specular);
        glMaterialfv(GL_FRONT_AND_BACK, GL_SHININESS, material_shininess);
        break;
    case'M':
    case'm':
        material_ambient[0] = 1.0; material_ambient[1] = 1.0; material_ambient[2] = 1.0; material_ambient[3] = 1.000000;
        material_diffuse[0] = 1.0; material_diffuse[1] = 1.0; material_diffuse[2] = 1.0; material_diffuse[3] = 1.000000;
        material_specular[0] = 1.0; material_specular[1] = 1.0; material_specular[2] = 1.0; material_specular[3] = 1.000000;
        material_shininess[0] = 100.0;
        glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT, material_ambient);
        glMaterialfv(GL_FRONT_AND_BACK, GL_DIFFUSE, material_diffuse);
        glMaterialfv(GL_FRONT_AND_BACK, GL_SPECULAR, material_specular);
        glMaterialfv(GL_FRONT_AND_BACK, GL_SHININESS, material_shininess);
        break;
    case'O':
    case'o':
        glEnable(GL_LIGHT0);
        glDisable(GL_LIGHT1);
        break;
    case'P':
    case'p':
        glEnable(GL_LIGHT1);
        glDisable(GL_LIGHT0);
        break;
    case 27:
        exit(0);
        break;
    }
    glutPostRedisplay();
}

void mouse(int x, int y)
{
    if(movFlag){
        gazeX = (x - glutGet(GLUT_WINDOW_WIDTH) / 2) * 0.01;
        gazeY = (glutGet(GLUT_WINDOW_HEIGHT) / 2 - y) * 0.01;
    }

    glutPostRedisplay();
}
int main(int argc, char** argv)
{
    glutInit(&argc, argv);
    //glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB);
    //glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB | GLUT_DEPTH);
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
    glutInitWindowSize(500, 500);
    glutInitWindowPosition(100, 100);
    glutCreateWindow(argv[0]);
    init();
    glutDisplayFunc(display);
    glutReshapeFunc(reshape);
    glutIdleFunc(idlefunc);
    glutKeyboardFunc(keyboard);
    glutPassiveMotionFunc(mouse);
    glutMainLoop();
    return 0;
}
