#include <GL/glut.h>
#include <vector>
#include <cmath>
#include <ctime>
#include <cstdlib>
using namespace std;

vector<std::pair<float, float>> controlPoints;
GLfloat t = 0.0f;

int binomialCoeff(int n, int k) {
    int res = 1;
    if (k > n - k)
        k = n - k;
    for (int i = 0; i < k; ++i) {
        res *= (n - i);
        res /= (i + 1);
    }
    return res;
}

pair<float, float> calculateBezierPoint(float t, vector<pair<float, float>> points) {
    int n = points.size() - 1;
    float x = 0.0f;
    float y = 0.0f;
    for (int i = 0; i <= n; ++i) {
        int binom = binomialCoeff(n, i);
        float coeff = binom * pow(1 - t, n - i) * pow(t, i);
        x += coeff * points[i].first;
        y += coeff * points[i].second;
    }
    return std::make_pair(x, y);
}

void init() {
    glClearColor(1.0, 1.0, 1.0, 1.0);
    glColor3f(0.0, 0.0, 0.0);
    glMatrixMode(GL_PROJECTION);
    gluOrtho2D(0.0, 800.0, 0.0, 600.0);
    controlPoints.push_back(std::make_pair(100,100));
    controlPoints.push_back(std::make_pair(500,300));
    controlPoints.push_back(std::make_pair(100,500));
}

void display() {
    glClear(GL_COLOR_BUFFER_BIT);

    if (controlPoints.size() < 2) {
        glutSwapBuffers();
        return;
    }

    srand(time(0));
    std::vector<std::pair<float, float>> tempPoints = controlPoints;
    while (tempPoints.size() > 1) {
        GLfloat r = rand() % 100 / 100.0;
        GLfloat g = rand() % 100 / 100.0;
        GLfloat b = rand() % 100 / 100.0;
        glColor3f(r, g, b); 
        glBegin(GL_LINE_STRIP);
        for (const auto& point : tempPoints) {
            glVertex2f(point.first, point.second);
        }
        glEnd();

        std::vector<std::pair<float, float>> newTempPoints;
        for (size_t i = 0; i < tempPoints.size() - 1; ++i) {
            float newX = (1 - t) * tempPoints[i].first + t * tempPoints[i + 1].first;
            float newY = (1 - t) * tempPoints[i].second + t * tempPoints[i + 1].second;
            newTempPoints.push_back(std::make_pair(newX, newY));
        }
        tempPoints = newTempPoints;
    }

    GLfloat r = rand() % 100 / 100.0;
    GLfloat g = rand() % 100 / 100.0;
    GLfloat b = rand() % 100 / 100.0;
    glColor3f(r, g, b);
    glBegin(GL_LINE_STRIP);
    for (float tempT = 0.0; tempT <= t; tempT += 0.01) {
        auto point = calculateBezierPoint(tempT, controlPoints);
        glVertex2f(point.first, point.second);
    }
    glEnd();

    glPointSize(5.0);
    glBegin(GL_POINTS);
    for (const auto& point : controlPoints) {
        glVertex2f(point.first, point.second);
    }
    glEnd();

    glutSwapBuffers();
}

void timer(int value) {
    if (t < 1.0f) {
        t += 0.01f;
        glutPostRedisplay();
        glutTimerFunc(100, timer, 0); 
    }
    if (t >= 1.0f)
        t = 0.0f;
}

void mouse(int button, int state, int x, int y) {
    if (button == GLUT_LEFT_BUTTON && state == GLUT_DOWN) {
        controlPoints.push_back(std::make_pair(x, 600 - y));
        t = 0.0f; 
        glutPostRedisplay();
        glutTimerFunc(30, timer, 0);
    }
}

int main(int argc, char** argv) {
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB);
    glutInitWindowSize(800, 600);
    glutInitWindowPosition(100, 100);
    glutCreateWindow("Bezier");
    init();
    glutDisplayFunc(display);
    glutMouseFunc(mouse);
    glutTimerFunc(30, timer, 0);
    glutMainLoop();
    return 0;
}
