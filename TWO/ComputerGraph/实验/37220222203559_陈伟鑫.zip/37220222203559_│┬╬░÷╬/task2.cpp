#include <GL/glut.h>
#include <vector>
#include <cmath>
#include <ctime>
#include <cstdlib>
using namespace std;

vector<pair<float, float>> controlPoints1;
vector<pair<float, float>> controlPoints2;
vector<pair<float, float>> controlPoints3;
GLfloat t = 0.0f;
GLfloat r, g, b;
int movingPoint = -1;

int binomialCoeff(int n, int k) {
    int res = 1;
    if (k > n - k)
        k = n - k;
    for (int i = 0; i < k; ++i) {
        res *= (n - i);
        res /= (i + 1);
    }
    return res;
}

pair<float, float> calculateBezierPoint(float t, vector<pair<float, float>> points) {
    int n = points.size() - 1;
    float x = 0.0f;
    float y = 0.0f;
    for (int i = 0; i <= n; ++i) {
        int binom = binomialCoeff(n, i);
        float coeff = binom * pow(1 - t, n - i) * pow(t, i);
        x += coeff * points[i].first;
        y += coeff * points[i].second;
    }
    return std::make_pair(x, y);
}

void init() {
    glClearColor(1.0, 1.0, 1.0, 1.0);
    glColor3f(0.0, 0.0, 0.0);
    glMatrixMode(GL_PROJECTION);
    gluOrtho2D(0.0, 800.0, 0.0, 600.0);
    controlPoints1.push_back(make_pair(100, 100));
    controlPoints1.push_back(make_pair(200, 200));
    controlPoints1.push_back(make_pair(300, 300));
    controlPoints1.push_back(make_pair(200, 400));
    controlPoints1.push_back(make_pair(100, 500));
    controlPoints2.push_back(make_pair(300, 100));
    controlPoints2.push_back(make_pair(400, 200));
    controlPoints2.push_back(make_pair(500, 300));
    controlPoints2.push_back(make_pair(400, 400));
    controlPoints2.push_back(make_pair(300, 500));
    controlPoints3.push_back(make_pair(500, 100));
    controlPoints3.push_back(make_pair(600, 200));
    controlPoints3.push_back(make_pair(700, 300));
    controlPoints3.push_back(make_pair(600, 400));
    controlPoints3.push_back(make_pair(500, 500));
}

void drawCurve(vector<pair<float, float>>& controlPoints) {
    glBegin(GL_LINE_STRIP);
    for (float tempT = 0.0; tempT <= 1; tempT += 0.01) {
        auto point = calculateBezierPoint(tempT, controlPoints);
        glVertex2f(point.first, point.second);
    }
    glEnd();

    glPointSize(5.0);
    glBegin(GL_POINTS);
    for (const auto& point : controlPoints) {
        glVertex2f(point.first, point.second);
    }
    glEnd();
}

void drawSurface() {
    vector<vector<pair<float, float>>> controlPoints = { controlPoints1, controlPoints2, controlPoints3 };
    int uCount = 30, vCount = 30;

    for (int i = 0; i <= uCount; ++i) {
        float u = i / (float)uCount;
        glBegin(GL_LINE_STRIP);
        for (int j = 0; j <= vCount * t; ++j) { 
            float v = j / (float)vCount;
            vector<pair<float, float>> curve;
            for (int k = 0; k < controlPoints.size(); ++k) {
                curve.push_back(calculateBezierPoint(v, controlPoints[k]));
            }
            auto point = calculateBezierPoint(u, curve);
            glVertex2f(point.first, point.second);
        }
        glEnd();
    }

    for (int j = 0; j <= vCount; ++j) {
        float v = j / (float)vCount;
        glBegin(GL_LINE_STRIP);
        for (int i = 0; i <= uCount * t; ++i) { 
            float u = i / (float)uCount;
            vector<pair<float, float>> curve;
            for (int k = 0; k < controlPoints.size(); ++k) {
                curve.push_back(calculateBezierPoint(v, controlPoints[k]));
            }
            auto point = calculateBezierPoint(u, curve);
            glVertex2f(point.first, point.second);
        }
        glEnd();
    }
}

void display() {
    glClear(GL_COLOR_BUFFER_BIT);
    drawCurve(controlPoints1);
    drawCurve(controlPoints2);
    drawCurve(controlPoints3);
    drawSurface();
    glutSwapBuffers();
}

void timer(int value) {
    t += 0.01f;
    if (t > 1.0f) {
        t = 0.0f;
    }
    glutPostRedisplay();
    glutTimerFunc(30, timer, 0);
}

void mouse(int button, int state, int x, int y) {
    if (button == GLUT_LEFT_BUTTON && state == GLUT_DOWN) {
        int windowHeight = glutGet(GLUT_WINDOW_HEIGHT);
        float wx = (float)x;
        float wy = (float)(windowHeight - y);

        float minDist = 10.0f;
        movingPoint = -1;

        for (int i = 0; i < controlPoints1.size(); ++i) {
            if (sqrt(pow(wx - controlPoints1[i].first, 2) + pow(wy - controlPoints1[i].second, 2)) < minDist) {
                movingPoint = i;
                break;
            }
        }

        if (movingPoint == -1) {
            for (int i = 0; i < controlPoints2.size(); ++i) {
                if (sqrt(pow(wx - controlPoints2[i].first, 2) + pow(wy - controlPoints2[i].second, 2)) < minDist) {
                    movingPoint = i + controlPoints1.size();
                    break;
                }
            }
        }

        if (movingPoint == -1) {
            for (int i = 0; i < controlPoints3.size(); ++i) {
                if (sqrt(pow(wx - controlPoints3[i].first, 2) + pow(wy - controlPoints3[i].second, 2)) < minDist) {
                    movingPoint = i + controlPoints1.size() + controlPoints2.size();
                    break;
                }
            }
        }
    }
    else if (button == GLUT_LEFT_BUTTON && state == GLUT_UP) {
        movingPoint = -1;
    }
}

void motion(int x, int y) {
    if (movingPoint != -1) {
        t = 0;
        int windowHeight = glutGet(GLUT_WINDOW_HEIGHT);
        float wx = (float)x;
        float wy = (float)(windowHeight - y);

        if (movingPoint < controlPoints1.size()) {
            controlPoints1[movingPoint] = make_pair(wx, wy);
        }
        else if (movingPoint < controlPoints1.size() + controlPoints2.size()) {
            controlPoints2[movingPoint - controlPoints1.size()] = make_pair(wx, wy);
        }
        else {
            controlPoints3[movingPoint - controlPoints1.size() - controlPoints2.size()] = make_pair(wx, wy);
        }

        glutPostRedisplay();
    }
}

int main(int argc, char** argv) {
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB);
    glutInitWindowSize(800, 600);
    glutInitWindowPosition(100, 100);
    glutCreateWindow("Bezier Surface");
    init();
    glutDisplayFunc(display);
    glutMouseFunc(mouse);
    glutMotionFunc(motion);
    glutTimerFunc(30, timer, 0);
    glutMainLoop();
    return 0;
}
