#ifdef __APPLE__
#include <GLUT/glut.h>
#else
#include <GL/glut.h>         /* glut.h includes gl.h and glu.h*/
#endif
#include <cmath>
#define PI 3.14159265359

static double rotation_angle = 0.0;
void display(void)

{
	glClear(GL_COLOR_BUFFER_BIT);

	/* ������ת���� */
	glPushMatrix();
	glRotatef(rotation_angle, 0.0f, 0.0f, 1.0f);
	
	/* draw unit square polygon */
	glColor4f(255, 255, 0, 1);
	glBegin(GL_POLYGON);
	float theta = 0;
	int r = 1;
	glVertex2f(0, 0);
	for (; theta <= 1.0 * 360 / 7; theta+=0.1)
		glVertex2f(r * cos(theta / 180 * PI), r * sin(theta / 180 * PI));
	glEnd();

	glColor4f(0, 255, 255, 1);
	glBegin(GL_POLYGON);
	glVertex2f(0, 0);
	for (theta = 360 * 1.0 / 7; theta <= 2.0 * 360 / 7; theta += 0.1)
		glVertex2f(r * cos(theta / 180 * PI), r * sin(theta / 180 * PI));
	glEnd();


	glColor4f(255, 0, 255, 1);
	glBegin(GL_POLYGON);
	glVertex2f(0, 0);
	for (theta = 360 * 2.0 / 7; theta <= 360 * 3.0 / 7; theta += 0.1)
		glVertex2f(r * cos(theta / 180 * PI), r * sin(theta / 180 * PI));
	glEnd();


	glColor4f(0, 255, 0, 1);
	glBegin(GL_POLYGON);
	glVertex2f(0, 0);
	for (theta = 360 * 3.0 / 7; theta <= 4.0 * 360 / 7; theta += 0.1)
		glVertex2f(r * cos(theta / 180 * PI), r * sin(theta / 180 * PI));
	glEnd();


	glColor4f(0, 0, 255, 1);
	glBegin(GL_POLYGON);
	glVertex2f(0, 0);
	for (theta = 360 * 4.0 / 7; theta <= 5.0 * 360 / 7; theta += 0.1)
		glVertex2f(r * cos(theta / 180 * PI), r * sin(theta / 180 * PI));
	glEnd();


	glColor4f(255, 0, 0, 1);
	glBegin(GL_POLYGON);
	glVertex2f(0, 0);
	for (theta = 360 * 5.0 / 7; theta <= 6.0 * 360 / 7; theta += 0.1)
		glVertex2f(r * cos(theta / 180 * PI), r * sin(theta / 180 * PI));
	glEnd();

	glColor4f(50, 127, 255, 1);
	glBegin(GL_POLYGON);
	glVertex2f(0, 0);
	for (theta = 360 * 6.0 / 7; theta <= 7.0 * 360 / 7; theta += 0.1)
		glVertex2f(r * cos(theta / 180 * PI), r * sin(theta / 180 * PI));
	glEnd();

	glPopMatrix();

	glFlush();

}

void update(int value)
{
	/* ������ת�Ƕ� */
	rotation_angle += 1.0;
	if (rotation_angle >= 360) {
		rotation_angle = 0;
	}

	/* �ػ洰�� */
	glutPostRedisplay();

	/* ����һ��ʱ�����ٴε��ô˺��� */
	glutTimerFunc(25, update, 0);
}

int main(int argc, char** argv)
{

	/* Initialize mode and open a window in upper left corner of screen */
	/* Window title is name of program (arg[0]) */

	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB);
	glutInitWindowSize(700, 700);
	glutInitWindowPosition(0, 0);
	glutCreateWindow("simple");
	glutDisplayFunc(display);
	glutTimerFunc(25, update, 0);
	glutMainLoop();
	return 0;
}