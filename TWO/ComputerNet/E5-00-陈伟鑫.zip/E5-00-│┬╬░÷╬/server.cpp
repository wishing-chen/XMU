#define  _CRT_SECURE_NO_WARNINGS
#include <iostream>
#include <WinSock2.h>
#include <WS2tcpip.h>
#include <ctime>
#include <cstdlib>
#include <map>
#include <string>
#include <thread>
#pragma comment(lib,"Ws2_32.lib")

typedef struct licensemsg {
    int maxnum;
    int nownum;
}licensemsg;
std::map<long long, licensemsg> license;
std::map<std::string, long long>user;
const int PORT = 8888;

// �����ͻ���������̺߳���
void clientThread(SOCKET clientSocket)
{
    srand(time(NULL));
    sockaddr_in clientAddr;
    int addrLen = sizeof(clientAddr);
    getpeername(clientSocket, (struct sockaddr*)&clientAddr, &addrLen);
    char ip[INET_ADDRSTRLEN];
    inet_ntop(AF_INET, &(clientAddr.sin_addr), ip, INET_ADDRSTRLEN);

    char getmsg[1024];
    char sendmsg[1024];
    long long licensenumber = 0;
    {
        int bytesRead = recv(clientSocket, getmsg, 1024, 0);
        snprintf(getmsg, bytesRead, "%s", getmsg);
        if (getmsg[0] != 'n') {
            char str1[100];
            char str2[100];
            char str3[100];
            int licensekind;
            sscanf(getmsg, "%s %s %s %d", str1, str2, str3, &licensekind);
            //std::cout << licensekind << std::endl;
            //std::cout << str1;
            std::string rep = str1;
            if (rep == "y") {
                for (int i = 0; i < 10; ++i) {
                    int num = rand() % 10;
                    if (num == 0)
                        num++;
                    licensenumber = licensenumber * 10 + num;
                }
                sprintf(sendmsg, "%s:%lld", "�������к�Ϊ", licensenumber);
                send(clientSocket, sendmsg, strlen(sendmsg) + 1, 0);
                licensemsg msg;
                msg.maxnum = (licensekind == 0) ? 10 : 50;
                msg.nownum = 0;
                license[licensenumber] = msg;
            }
        }
    }
    {
        std::string s_ip = ip;
        if (user.find(s_ip) == user.end()) {
            sprintf(sendmsg, "%s %d", "��һ��ʹ������,���������к�", 0);
            send(clientSocket, sendmsg, strlen(sendmsg) + 1, 0);

            int bytesRead = recv(clientSocket, getmsg, 1024, 0);
            long long temp;
            temp = atoll(getmsg);
            //std::cout << temp << std::endl;
            if (bytesRead < 0)
                return;
            snprintf(getmsg, bytesRead, "%s", getmsg);
            sscanf(getmsg, "%lld", &licensenumber);

            user[s_ip] = licensenumber;
        }
        else {
            sprintf(sendmsg, "%s %d", "֮ǰʹ�ù���������ֱ�ӽ���", 1);
            send(clientSocket, sendmsg, strlen(sendmsg) + 1, 0);
        }
    }
    {
        if (license[user[ip]].nownum >= license[user[ip]].maxnum) {
            if (license[user[ip]].maxnum == 0) {
                sprintf(sendmsg, "%s %d", "���кŲ���ȷ", 1);
                send(clientSocket, sendmsg, strlen(sendmsg) + 1, 0);
            }
            else {
                sprintf(sendmsg, "%s %d", "ʹ���������࣬���Ե�", 1);
                send(clientSocket, sendmsg, strlen(sendmsg) + 1, 0);
            }
        }
        else {
            sprintf(sendmsg, "%s %d", "��Ȩʹ��", 0);
            send(clientSocket, sendmsg, strlen(sendmsg) + 1, 0);
            license[user[ip]].nownum++;
            while (true) {
                int bytesRead = recv(clientSocket, getmsg, 1024, 0);
                if (bytesRead < 0) 
                {
                    license[user[ip]].nownum--;
                    std::cout << "�����ж�" << std::endl;
                    break;
                }
                snprintf(getmsg, bytesRead, "%s", getmsg);
                std::cout << getmsg << std::endl;
            }
        }
    }

    // �رտͻ�������
    closesocket(clientSocket);
}

int main0()
{
    WSADATA wsaData;
    SOCKET serverSocket, clientSocket;
    struct sockaddr_in serverAddress, clientAddress;
    int clientAddressLength = sizeof(clientAddress);

    // ��ʼ�� Winsock
    if (WSAStartup(MAKEWORD(2, 2), &wsaData) != 0)
    {
        std::cerr << "��ʼ�� Winsock ʧ��" << std::endl;
        return -1;
    }

    // �����׽���
    serverSocket = socket(AF_INET, SOCK_STREAM, 0);
    if (serverSocket == INVALID_SOCKET)
    {
        std::cerr << "�����׽���ʧ��" << std::endl;
        return -1;
    }

    // ���÷�������ַ�Ͷ˿�
    serverAddress.sin_family = AF_INET;
    serverAddress.sin_addr.s_addr = INADDR_ANY;
    serverAddress.sin_port = htons(PORT);

    // ���׽��ֵ���������ַ�Ͷ˿�
    if (bind(serverSocket, (struct sockaddr*)&serverAddress, sizeof(serverAddress)) == SOCKET_ERROR)
    {
        std::cerr << "���׽���ʧ��" << std::endl;
        return -1;
    }

    // ��������
    if (listen(serverSocket, 5) == SOCKET_ERROR)
    {
        std::cerr << "����ʧ��" << std::endl;
        return -1;
    }

    while (true)
    {
        // ���ܿͻ�������
        clientSocket = accept(serverSocket, (struct sockaddr*)&clientAddress, &clientAddressLength);
        if (clientSocket == INVALID_SOCKET) {
            std::cerr << "��������ʧ��" << std::endl;
            continue;
        }
        // �����̴߳����ͻ�������
        std::thread clientThreadOBJ(clientThread, clientSocket);
        clientThreadOBJ.detach(); // �����̣߳�ʹ�������������Զ��ͷ���Դ
    }

    // �رշ������׽���
    closesocket(serverSocket);

    // ���� Winsock
    WSACleanup();

    return 0;
}