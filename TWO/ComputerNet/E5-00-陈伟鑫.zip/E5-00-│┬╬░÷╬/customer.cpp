#define  _CRT_SECURE_NO_WARNINGS
#include <iostream>
#include <cstring>
#include <WS2tcpip.h>
#include <winsock2.h>
#include <string>
#include <thread>
using namespace std;
#pragma comment(lib, "ws2_32.lib")
int flag = 1;
const int PORT = 8888;
const char* SERVER_IP = "127.0.0.1";

void otherthread(SOCKET clientSocket) {
  
    while (true)
    {
        string report = "RUNNING!";

        if (send(clientSocket, report.c_str(), report.size() + 1, 0) < 0)
        {
            cerr << "RUNNING BAD!" << std::endl;
            flag = 10;
            return;
        }
        
        this_thread::sleep_for(chrono::seconds(5));
    }
}

int main() {
    WSADATA wsaData;
    SOCKET clientSocket;
    struct sockaddr_in serverAddress;
    while (flag--) {
        // ��ʼ�� Winsock
        if (WSAStartup(MAKEWORD(2, 2), &wsaData) != 0) {
            std::cerr << "��ʼ�� Winsock ʧ��" << std::endl;
            continue;
        }

        // �����׽���
        clientSocket = socket(AF_INET, SOCK_STREAM, 0);
        if (clientSocket == INVALID_SOCKET) {
            std::cerr << "�����׽���ʧ��" << std::endl;
            continue;
        }

        // ���÷�������ַ�Ͷ˿�
        serverAddress.sin_family = AF_INET;
        serverAddress.sin_port = htons(PORT);
        if (inet_pton(AF_INET, SERVER_IP, &(serverAddress.sin_addr)) <= 0) {
            std::cerr << "��Ч�ķ�������ַ" << std::endl;
            continue;
        }

        // ���ӷ�����

        if (connect(clientSocket, (struct sockaddr*)&serverAddress, sizeof(serverAddress)) < 0) {
            std::cerr << "���ӷ�����ʧ��" << std::endl;
            continue;
        }

        char sendmsg[1024];
        char getmsg[1024];
        {
            cout << "��ѡ���ǹ�������֤�����������кŵ�¼��(y/n)��y��ʾǰ�ߣ�" << endl;
            string rep;
            cin >> rep;
            if (rep == "y") {
                string username;
                string password;
                int licensekind;
                cout << "�������û���" << endl;
                cin >> username;
                cout << "���������" << endl;
                cin >> password;
                cout << "����������֤����" << endl;
                cin >> licensekind;
                sprintf(sendmsg, "%s %s %s %d", rep.c_str(), username.c_str(), password.c_str(), licensekind);
                //cout << sendmsg;
                //cout << strlen(sendmsg);
                send(clientSocket, sendmsg, strlen(sendmsg) + 1, 0);
                int bytesRead = recv(clientSocket, getmsg, 1024, 0);
                snprintf(getmsg, bytesRead, "%s", getmsg);
                if (bytesRead > 0) {
                    std::cout << getmsg << std::endl;
                }
            }
            else {
                sprintf(sendmsg, "%s", rep.c_str());
                send(clientSocket, sendmsg, strlen(sendmsg) + 1, 0);
            }
        }
        {

            char str1[1024];
            int state;
            int bytesRead = recv(clientSocket, getmsg, 1024, 0);
            snprintf(getmsg, bytesRead, "%s", getmsg);
            sscanf(getmsg, "%s %d", str1, &state);
            std::cout << str1 << std::endl;

            if (state == 0) {
                long long licensenumber;
                cin >> licensenumber;
                sprintf(sendmsg, "%lld", licensenumber);
                send(clientSocket, sendmsg, strlen(sendmsg) + 1, 0);
            }
        }
        {
            char str1[1024];
            int state;
            int bytesRead = recv(clientSocket, getmsg, 1024, 0);
            snprintf(getmsg, bytesRead, "%s", getmsg);
            sscanf(getmsg, "%s %d", str1, &state);
            std::cout << str1 << std::endl;
            //std::cout << state << endl;
            if (state == 0) {
                otherthread(clientSocket);
            }
        }

        // �ر��׽���
        closesocket(clientSocket);

        // ���� Winsock
        WSACleanup();
    }
    return 0;
}