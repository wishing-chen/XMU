package com.example.lab4fx;

import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

public class DrawController {
    @FXML
    TextField inputBox = new TextField();
}