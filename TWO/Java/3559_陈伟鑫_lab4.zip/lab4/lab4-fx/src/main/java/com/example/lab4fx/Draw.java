package com.example.lab4fx;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Line;
import javafx.scene.shape.Rectangle;
import javafx.scene.shape.Ellipse;
import javafx.stage.Stage;
import java.security.SecureRandom;
import java.util.Scanner;

public class Draw extends Application {
    private static final int WIDTH = 800;
    private static final int HEIGHT = 600;
    private static final int MAX_SHAPES = 20;
    private Pane root;
    private Scanner scanner;
    @Override
    public void start(Stage primaryStage) {
        root = new Pane();
        SecureRandom random = new SecureRandom();

        for (int i = 0; i < MAX_SHAPES; i++) {
            int shapeType = random.nextInt(3);
            switch (shapeType) {
                case 0:
                    drawLine();
                    break;
                case 1:
                    drawRectangle();
                    break;
                case 2:
                    drawEllipse();
                    break;
            }
        }
        Scene scene = new Scene(root, WIDTH, HEIGHT);
        primaryStage.setScene(scene);
        primaryStage.show();
    }
    private void drawLine() {
        scanner = new Scanner(System.in);
        double x1,y1,x2,y2;
        boolean isRightIn;
        do {
            System.out.println("请输入直线的起点与终点横纵坐标(0<x,y<500)");
            x1 = scanner.nextDouble();
            y1 = scanner.nextDouble();
            x2 = scanner.nextDouble();
            y2 = scanner.nextDouble();
            if(x1<0||x1>500||x2<0||x2>500||y1<0||y1>500||y2<0||y2>500){
                isRightIn = false;
                System.out.println("输入错误，请重新输入");
            }
            else
                isRightIn = true;
        }while(!isRightIn);
        Line line = new Line(x1, y1, x2, y2);
        line.setStroke(Color.BLACK);
        root.getChildren().add(line);
    }
    private void drawRectangle() {
        scanner = new Scanner(System.in);
        double x,y,width,height;
        boolean isRightIn;
        do {
            System.out.println("请输入矩形的起始横纵坐标(0<x,y<500)，以及长与宽(0,500)");
            x = scanner.nextDouble();
            y = scanner.nextDouble();
            width = scanner.nextDouble();
            height = scanner.nextDouble();
            if(x<0||x>500||y<0||y>500||width<0||width>500||height<0||height>500) {
                isRightIn = false;
                System.out.println("输入错误，请重新输入");
            }
            else
                isRightIn = true;
        }while(!isRightIn);

        Rectangle rectangle = new Rectangle(x, y, width, height);
        rectangle.setFill(Color.TRANSPARENT);
        rectangle.setStroke(Color.BLACK);
        root.getChildren().add(rectangle);
    }
    private void drawEllipse() {
        scanner = new Scanner(System.in);
        boolean isRightIn;
        double centerX,centerY,radiusX,radiusY;
        do{
            System.out.println("请输入椭圆的中心横纵坐标(0<x,y<500)，以及半长轴与半短轴(0,500)");
            centerX = scanner.nextDouble();
            centerY = scanner.nextDouble();
            radiusX = scanner.nextDouble();
            radiusY = scanner.nextDouble();
            if(centerX<0||centerX>500||centerY<0||centerY>500||radiusX<0||radiusX>500||radiusY<0||radiusY>500){
                isRightIn = false;
                System.out.println("输入错误，请重新输入");
            }
            else
                isRightIn = true;
        }while(!isRightIn);

        Ellipse ellipse = new Ellipse(centerX, centerY, radiusX, radiusY);
        ellipse.setFill(Color.TRANSPARENT);
        ellipse.setStroke(Color.BLACK);
        root.getChildren().add(ellipse);
    }

    public static void main(String[] args) {
        launch(args);
    }
}