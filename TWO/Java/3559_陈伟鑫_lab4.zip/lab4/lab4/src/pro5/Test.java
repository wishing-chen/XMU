package pro5;

public class Test {
    public static void main(String[] args)
    {
        for(TrafficLight light : TrafficLight.values())
        {
            int[] rgb = light.getRgb();
            System.out.println(light.name()+" RGB:("+rgb[0]+","+rgb[1]+","+rgb[2]+")");
        }
    }
}
