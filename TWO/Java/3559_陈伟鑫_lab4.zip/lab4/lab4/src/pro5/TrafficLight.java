package pro5;

public enum TrafficLight {
    RED(255,0,0),
    YELLOW(255,255,0),
    GREEN(0,255,0);

    private final int[] rgb;
    TrafficLight(int red,int green,int blue)
    {
        this.rgb = new int[]{red,green,blue};
    }
    public int[] getRgb()
    {
        return rgb;
    }

}
