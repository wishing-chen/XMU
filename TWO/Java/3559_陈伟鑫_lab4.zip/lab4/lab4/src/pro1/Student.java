package pro1;

import java.util.ArrayList;
import java.util.List;

class Student {
    private String id;
    private String name;
    private String className;
    private List<Course> courses = new ArrayList<>();
    Student(String id, String name, String className) {
        this.id = id;
        this.name = name;
        this.className = className;
    }
    public void printInfo() {
        System.out.println("ID: " + id + ", Name: " + name + ", Class: " + className);
    }
    public List<Course> getCourses()
    {
        return courses;
    }
    public void ChooseCourse(Course course)
    {
        this.courses.add(course);
    }
}