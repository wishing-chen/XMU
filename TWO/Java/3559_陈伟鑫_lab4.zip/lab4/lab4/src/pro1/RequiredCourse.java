package pro1;

public class RequiredCourse extends Course{

    RequiredCourse(String code,String name,int credits)
    {
        super(code,name,credits);
    }

}
