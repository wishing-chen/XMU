package pro1;

public class Undergraduate extends Student{
    Undergraduate(String id,String name,String classname)
    {
        super(id,name,classname);
    }
}
