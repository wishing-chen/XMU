package pro1;

public class Graduate extends Student
{
    private String teacher;

    Graduate(String id,String name,String className,String teacher)
    {
        super(id,name,className);
        this.teacher=teacher;
    }

    public void printInfo() {
        super.printInfo();
        System.out.println("Teacher: " + teacher);
    }
}
