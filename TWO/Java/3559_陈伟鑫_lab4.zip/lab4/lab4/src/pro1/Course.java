package pro1;

public class Course {
    private String code;
    private String name;
    private int credits;

    Course(String code, String name, int credits) {
        this.code = code;
        this.name = name;
        this.credits = credits;
    }

    public void printInfo() {
        System.out.println("Code: " + code + ", Name: " + name + ", Credits: " + credits);
    }
}
