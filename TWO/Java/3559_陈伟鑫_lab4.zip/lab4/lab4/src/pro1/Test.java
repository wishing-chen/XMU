package pro1;
import java.util.List;
import java.util.Scanner;

public class Test{
    private static void autoChoose(Graduate[] graduates,Undergraduate[] undergraduates,RequiredCourse[] requiredCourses)
    {
        for(int i=0;i<2;i++)
            for(int j=0;j<2;j++) {
                graduates[i].ChooseCourse(requiredCourses[j]);
                undergraduates[i].ChooseCourse(requiredCourses[j]);
            }
    }
    private static void selectChoose(Graduate[] graduates,Undergraduate[] undergraduates,ElectiveCourse[] electiveCourse)
    {
        Scanner scanner = new Scanner(System.in);
        for(int j=0;j<2;j++)
        {
            System.out.println("请为本科生");
            undergraduates[j].printInfo();
            System.out.println("选择一至两门课");
            for(int k=0;k<2;k++) {
                System.out.print(k+1+": ");
                electiveCourse[k].printInfo();
            }
            String str = scanner.nextLine();
            String[] temp = str.split(" ");
            for (String s : temp) undergraduates[j].ChooseCourse(electiveCourse[Integer.parseInt(s)-1]);
        }
        for(int j=0;j<2;j++)
        {
            System.out.println("请为研究生");
            graduates[j].printInfo();
            System.out.println("选择一至两门课");
            for(int k=0;k<2;k++)
                electiveCourse[k].printInfo();
            String str = scanner.nextLine();
            String[] temp = str.split(" ");
            for (String s : temp) graduates[j].ChooseCourse(electiveCourse[Integer.parseInt(s)-1]);
        }
    }
    private static void printInfo(Graduate[] graduates,Undergraduate[] undergraduates)
    {
        for(int i=0;i<2;i++) {
            System.out.println("本科生：");
            undergraduates[i].printInfo();
            System.out.println("选择了：");
            for (Course temp : undergraduates[i].getCourses()) {
                temp.printInfo();
            }
        }
        for(int i=0;i<2;i++) {
            System.out.println("研究生：");
            graduates[i].printInfo();
            System.out.println("选择了：");
            for (Course temp : graduates[i].getCourses()) {
                temp.printInfo();
            }
        }
    }
    public static void main(String[] args)
    {
        Graduate[] graduate = new Graduate[]{
                new Graduate("1001","chen","13","wang"),
                new Graduate("1002","liu","02","li")};
        Undergraduate[] undergraduate = new Undergraduate[]{
                new Undergraduate("1003","yang","04"),
                new Undergraduate("1004","ma","10")};
        RequiredCourse[] requiredCourse = new RequiredCourse[]{
                new RequiredCourse("1122","java",4),
                new RequiredCourse("1042","c++",3)};
        ElectiveCourse[] electiveCourse = new ElectiveCourse[]{
                new ElectiveCourse("4312","python",3),
                new ElectiveCourse("3251","C#",2)};
        autoChoose(graduate,undergraduate,requiredCourse);
        selectChoose(graduate,undergraduate,electiveCourse);
        printInfo(graduate,undergraduate);
    }

}