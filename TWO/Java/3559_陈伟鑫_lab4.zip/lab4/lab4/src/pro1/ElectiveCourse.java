package pro1;

public class ElectiveCourse extends Course{
    ElectiveCourse(String code, String name, int credits)
    {
        super(code,name,credits);
    }
}
