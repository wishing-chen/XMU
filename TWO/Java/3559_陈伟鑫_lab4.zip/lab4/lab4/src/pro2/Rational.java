package pro2;

public class Rational extends Number implements  Comparable{
    private int numerator;
    private int denominator;
    Rational()
    {
        numerator = 1;
        denominator = 1;
    }
    @Override
    public int intValue() {
        return 0;
    }
    @Override
    public long longValue() {
        return 0;
    }
    @Override
    public float floatValue() {
        return 0;
    }
    @Override
    public double doubleValue() {
        return 0;
    }
    Rational(int num)
    {
        this.numerator = num;
        this.denominator = 1;
    }
    Rational(String num)
    {
        String[] split = num.split("/");
        numerator = Integer.parseInt(split[0]);
        denominator = Integer.parseInt(split[1]);
        if(denominator < 0){
            denominator = -denominator;
            numerator = -numerator;
        }
        simplified();
    }
    public int getNumerator()
    {
        return numerator;
    }
    public int getDenominator()
    {
        return denominator;
    }
    public void setNumerator(int numerator)
    {
        this.numerator = numerator;
    }
    public void setDenominator(int denominator) {
        this.denominator = denominator;
    }
    @Override
    public String toString()
    {
        double temp = (double) numerator /denominator;
        return temp+"";
    }
    public void simplified()
    {
        boolean isPlus;
        if(numerator >= 0)
            isPlus = true;
        else {
            numerator = -numerator;
            isPlus = false;
        }
        int temp = (int)Math.sqrt(Math.min(numerator, denominator));
        for(;temp>=2;temp--)
        {
            if(numerator%temp==0 && denominator%temp==0)
            {
                numerator/=temp;
                denominator/=temp;
            }
        }
        if(!isPlus)
            numerator = -numerator;
    }
    public Rational add(Rational temp)
    {
        Rational rational = new Rational();
        if(denominator<0) {
            denominator = -denominator;
            numerator = -numerator;
        }
        int x=temp.getNumerator();
        int y=temp.getDenominator();
        if(y<0){
            y=-y;
            x=-x;
        }
        int i=2;
        while(true) {
            if(i%denominator==0 && i%y==0)
                break;
            else
                ++i;
        }
        rational.setNumerator(i);
        rational.setDenominator(i/denominator*numerator + i/y*x);
        rational.simplified();
        return rational;
    }
    public Rational sub(Rational temp)
    {
        Rational rational = new Rational();
        if(denominator<0) {
            denominator = -denominator;
            numerator = -numerator;
        }
        int x=temp.getNumerator();
        int y=temp.getDenominator();
        if(y<0){
            y=-y;
            x=-x;
        }
        int i=2;
        while(true) {
            if(i%denominator==0 && i%y==0)
                break;
            else
                ++i;
        }
        rational.setNumerator(i);
        rational.setDenominator(i/denominator*numerator - i/y*x);
        rational.simplified();
        return rational;
    }
    public Rational mul(Rational temp)
    {
        Rational rational = new Rational();
        int x = this.numerator * temp.getNumerator();
        int y = this.denominator * temp.getDenominator();
        if(y < 0){
            y=-y;
            x=-x;
        }
        rational.setNumerator(x);
        rational.setDenominator(y);
        rational.simplified();
        return rational;
    }
    public Rational div(Rational temp)
    {
        Rational rational = new Rational();
        int x = this.numerator * temp.getDenominator();
        int y = this.denominator * temp.getNumerator();
        if(y < 0){
            y=-y;
            x=-x;
        }
        rational.setNumerator(x);
        rational.setDenominator(y);
        rational.simplified();
        return rational;
    }
    public void abs()
    {
        this.numerator = Math.abs(this.numerator);
        this.denominator = Math.abs(this.denominator);
    }
    public void isPlus()
    {
        if ((double)this.numerator/this.denominator>=0)
            System.out.println("正数");
        else
            System.out.println("负数");
    }
    @Override
    public boolean equals(Object obj)
    {
        Rational temp = new Rational();
        if(obj instanceof Rational)
            temp = (Rational)obj;
        return this.numerator == temp.getNumerator() && this.denominator == temp.getDenominator();
    }
    public int toInt()
    {
        double x = (double)numerator/denominator;
        return (int)x;
    }
    public double toDouble()
    {
        return (double)numerator/denominator;
    }
    @Override
    public int compareTo(Object obj)
    {
        Rational rational = new Rational();
        if(obj instanceof Rational)
            rational=(Rational) obj;
        if (numerator==rational.getNumerator()&&denominator==rational.getDenominator())
            return 0;
        else if(this.toDouble()>rational.toDouble())
            return 1;
        else return -1;
    }
}
