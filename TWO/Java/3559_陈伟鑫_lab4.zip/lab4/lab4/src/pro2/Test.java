package pro2;

public class Test {
    public static void main(String[] args)
    {
        Rational rational1 = new Rational(2);
        Rational rational2 = new Rational("-2/3");
        System.out.println(rational2.toInt());
        System.out.println(rational2.toDouble());
        System.out.println(rational2);
        Rational rational;
        rational = rational1.mul(rational2);
        System.out.println(rational);
        rational.isPlus();
        rational.abs();
        System.out.println(rational.compareTo(rational1));
    }
}
