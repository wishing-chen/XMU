package pro3;

abstract class Graph {
    abstract int calculateArea();
}
