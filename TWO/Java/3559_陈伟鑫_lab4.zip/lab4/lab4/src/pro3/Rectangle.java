package pro3;

public class Rectangle extends Graph{
    private int wide;
    private int height;
    Rectangle(){}
    Rectangle(int wide, int height)
    {
        this.wide = wide;
        this.height = height;
    }
    public void setWide(int wide)
    {
        this.wide = wide;
    }
    public void setHeight(int height)
    {
        this.height = height;
    }
    @Override
    public int calculateArea()
    {
        return wide * height;
    }
}
