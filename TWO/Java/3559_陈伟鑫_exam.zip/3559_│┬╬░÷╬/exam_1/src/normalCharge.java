public class normalCharge {
    // 父类充电桩
    private int id; // 编号
    private String loc; // 地点
    private String maxI; // 最大电流
    private String maxV; // 最大电压
    private boolean used; // 使用状态
    normalCharge(int id,String loc,String maxI,String maxV)
    {
        this.id = id;
        this.loc = loc;
        this.maxI = maxI;
        this.maxV = maxV;
        this.used = false; // 新增时默认未被使用
    }
    public void setUsed() {used = true;}
    public void setId(int id) {this.id = id;}
    public void setLoc(String loc) {this.loc = loc;}
    public void setMaxI(String maxI){this.maxI = maxI;}
    public void setMaxV(String maxV){this.maxV = maxV;}

    public int getId() {return id;}
    public boolean getUsed() {return used;}
    public String getLoc() {return loc;}
    public String getMaxI() {return maxI;}
    public String getMaxV() {return maxV;}

    public void display(){}


}
