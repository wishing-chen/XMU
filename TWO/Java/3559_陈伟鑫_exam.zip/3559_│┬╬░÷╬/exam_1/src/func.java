import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.security.SecureRandom;

public class func {
    double lowPer = 1.1; // 慢充每度电的收费 /元
    double highPer = 1.2; // 快充每度电的收费 /元
    double highTimePer = 1; // 快充每 20分钟 收的维护费 /元
    List<normalCharge> chargeList = new ArrayList<>(); // 用于存储所有充电桩的信息
    Scanner scanner = new Scanner(System.in);
    public void createCharge()
    {
        while(true)
        {
            System.out.println("请按照以下格式输入：");
            System.out.println("编号、位置、最大电流、电压");
            System.out.println("如：");
            System.out.println("快充 111 西部片区 400A 250KW");
            System.out.println("慢充 222 主校区 100A 6KW");
            System.out.println("其中“编号”为1-9999的整数");
            String str = scanner.nextLine();
            String[] info = str.split(" ");
            if(info.length != 5) //如果输入的信息不足5条，则判定输入太少
                System.out.println("输入信息个数有错");
            else if(info[0].equals("慢充") || info[0].equals("快充")){
                if(info[0].equals("慢充")){
                    int id= -1;
                    boolean flag = true;
                    // 判断输入的编号是否为整数，以及是否在1-9999之间
                    try{
                        id = Integer.parseInt(info[1]);
                    }catch (Exception e){
                        System.out.println("编号应该为整数");
                        flag = false;
                    }
                    if(id <1 || id>9999){
                        System.out.println("编号应为1-9999的整数");
                        flag = false;
                    }
                    // 如果所有条件都满足，则新增一个慢充
                    if(flag) {
                        chargeList.add(new lowCharge(id, info[2], info[3], info[4]));
                        System.out.println("新增成功！");
                    }
                }
                else{
                    int id= -1;
                    boolean flag = true;
                    //判断编号是否为整数，并且是否在1-9999之间
                    try{
                        id = Integer.parseInt(info[1]);
                    }catch (Exception e){
                        System.out.println("编号应该为整数");
                        flag = false;
                    }
                    if(id <1 || id>9999) {
                        System.out.println("编号应为1-9999的整数");
                        flag = false;
                    }
                    // 如果上述条件都满足，就创建一个快充
                    if(flag) {
                        chargeList.add(new highCharge(id, info[2], info[3], info[4]));
                        System.out.println("新增成功！");
                    }
                }
            }
            else
                System.out.println("第一项应为快充或慢充");
            // 每次新增后（无论成功与否）都想用户询问是否继续新增
            System.out.println("是否结束新增：");
            System.out.println("输入“Y”则结束新增，输入其他继续");
            String a = scanner.next();
            if(a.equals("Y"))
                break;
            else
                scanner.nextLine();
        }
    }
    public void charging()
    {
        SecureRandom random = new SecureRandom();
        int n = chargeList.size();
        int loop = n/2;
        //随机给一半的充电桩充电
        do {
            while (true) {
                // 只有当这个充电桩未被使用，才能使用这个充电桩
                int randomId = random.nextInt(n);
                if (!chargeList.get(randomId).getUsed()) {
                    chargeList.get(randomId).setUsed();
                    if(chargeList.get(randomId) instanceof lowCharge)
                        ((lowCharge) chargeList.get(randomId)).setPower(random.nextInt(70)+10);
                    else if(chargeList.get(randomId) instanceof highCharge) {
                        ((highCharge) chargeList.get(randomId)).setPower(random.nextInt(70)+10);
                        ((highCharge) chargeList.get(randomId)).setTime(random.nextInt(220)+20);
                    }
                    break;
                }
            }
            loop--;
        } while (loop != 0);
        System.out.println("充电成功！");
    }
    public void displayInfo()
    {
        // 循环输出充电桩的信息
        for(normalCharge e:chargeList)
            e.display();
    }
    public void displayFee()
    {
        //循环输出充电桩充电的信息
        for(normalCharge e:chargeList)
        {
            // 分类型计算使用的钱
            if(e instanceof lowCharge)
                System.out.println("编号："+ e.getId()+" 已使用: "+((lowCharge) e).getPower()*lowPer+"元");
            else
                System.out.println("编号："+ e.getId()+" 已使用："+(((highCharge) e).getPower()*highPer+  (Math.ceil(((highCharge) e).getTime() *1.0) / 20) *highTimePer)+"元");
        }
    }
    public void increase()
    {
        // 快充加钱！
        highPer *= 1.05;
    }
    public void home()
    {
        Scanner scanner = new Scanner(System.in);
        int choose = 5;
        boolean flag = true;
        while(flag){
            System.out.println("请输入命令编号：");
            System.out.println("1. 新增充电桩");
            System.out.println("2. 充电桩充电");
            System.out.println("3. 列出所有充电桩信息");
            System.out.println("4. 列出每台充电桩已充电费用");
            System.out.println("5. 将快速充电桩收费标准上涨5%");
            System.out.println("6. 退出");
            // 判断用户输入是否为1-6的整数
            try {
                choose = scanner.nextInt();
            } catch (Exception e) {
                scanner.nextLine();
            }
            switch (choose) // 对应每个功能
            {
                case 1: createCharge(); break;
                case 2: charging(); break;
                case 3: displayInfo(); break;
                case 4: displayFee(); break;
                case 5: increase(); break;
                case 6: flag = false;
                default:
            }
        }
    }
}
