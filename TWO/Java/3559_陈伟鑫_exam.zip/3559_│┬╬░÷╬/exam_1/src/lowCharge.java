public class lowCharge extends normalCharge{
    // 继承父类normalCharge
    private int power;// 使用的电量 /度
    lowCharge(int id,String loc,String maxI,String maxV)
    {
        super(id,loc,maxI,maxV);
        this.power = 0;
    }
    public int getPower() {return power;}
    public String getLoc() {
        return super.getLoc();
    }
    public String getMaxI() {
        return super.getMaxI();
    }
    public String getMaxV() {
        return super.getMaxV();
    }

    public void setPower(int power) {this.power = power;}
    public void setId(int id) {
        super.setId(id);
    }
    public void setLoc(String loc) {
        super.setLoc(loc);
    }
    public void setMaxI(String maxI) {
        super.setMaxI(maxI);
    }
    public void setMaxV(String maxV) {
        super.setMaxV(maxV);
    }
    public int getId()
    {
        return super.getId();
    }
    @Override
    public void display()
    {
        System.out.println("慢充桩"+" 编号："+super.getId()+" 位置："+ super.getLoc()+" 最大电流: "+super.getMaxI()+" 最大电压："+ super.getMaxV());
    }
}
