public class highCharge extends normalCharge{
    // 继承父类normalCharge
    private int power; // 使用的电量 /度
    private int time; // 使用的时间 / min
    highCharge(int id,String loc,String maxI,String maxV) {
        super(id, loc, maxI, maxV);
        this.power = 0;
        this.time = 0;
    }
    public int getPower() {return power;}
    public int getTime() {return time;}
    public int getId() {return super.getId();}
    public String getLoc() {
        return super.getLoc();
    }
    public String getMaxI() {
        return super.getMaxI();
    }
    public String getMaxV() {
        return super.getMaxV();
    }

    public void setPower(int power) {this.power = power;}
    public void setTime(int time) {this.time = time;}
    public void setId(int id) {
        super.setId(id);
    }
    public void setLoc(String loc) {
        super.setLoc(loc);
    }
    public void setMaxI(String maxI) {
        super.setMaxI(maxI);
    }
    public void setMaxV(String maxV) {
        super.setMaxV(maxV);
    }
    @Override
    public void display()
    {
        System.out.println("快充桩"+" 编号："+super.getId()+" 位置："+ super.getLoc()+" 最大电流: "+super.getMaxI()+" 最大电压："+ super.getMaxV());
    }

}
