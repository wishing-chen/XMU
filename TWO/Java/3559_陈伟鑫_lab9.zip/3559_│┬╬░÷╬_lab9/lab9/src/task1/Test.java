package task1;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;
public class Test {

    public static void main(String[] args)
    {
        Article article = new Article();
        article.toWord();
        System.out.println();
        article.SentenceContainsThe();
    }
}
