package task1;

import java.util.HashSet;
import java.util.Set;

public class Article {
    private String article = "PITTSBURGH (AP) — Carnegie Mellon University will hire a researcher from the Library of Congress to help it decode a collection that includes two WWII German Enigma machines.\n" +
            "The university wants to encourage the study of 19th and 20th century computers, calculators, encryption machines and other materials related to the history of computer science.\n" +
            "“When we look back and we see this, we see who we remember,” Andrew Moore, dean of CMU’s School of Computer Science, said, adding his students are increasingly asking for courses about the history of the field. “We see people who took technology to save lives and save the world.”\n" +
            "Pamela McCorduck, a prolific author on the history and future of artificial intelligence and the widow of Joseph Traub, a renowned computer scientist and the former head of CMU’s Computer Science Department, permanently loaned to the university a collection of early computers, books and letters. The collection, anchored by a three-rotor and four-rotor Enigma machine, is on display in the Fine and Rare Book Room in CMU’s Hunt Library in Oakland. The gift makes CMU one of a few institutions in the United States with Enigma machines. Even fewer display them.";
    public void toWord()
    {
        String[] words = article.split("[ .,“”()\\n—]+");
        Set<String> Word = new HashSet<>();
        for(String e:words)
            Word.add(e.toLowerCase());
        int count = 0;
        for(String e:Word) {
            count++;
            System.out.print(e + " ");
            if(count%10==0)
                System.out.println();
        }
        System.out.println();
    }
    public void SentenceContainsThe()
    {
        String[] sentences = article.split("[.\\n]+");
        for(String e:sentences)
            if(e.toLowerCase().contains("the"))
                System.out.println(e);
    }
}
