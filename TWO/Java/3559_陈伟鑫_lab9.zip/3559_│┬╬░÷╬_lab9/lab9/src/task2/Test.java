package task2;

import java.util.Scanner;

public class Test {
    public static void main(String[] args)
    {
        Scanner scanner = new Scanner(System.in);
        String UserName;
        String PassWord;
        String Email;
        while(true){
            System.out.println("请输入用户名（不能为空，只能由字母、数字和_组成，第一位不能为数字）");
            UserName = scanner.next();
            if (UserName == null) {
                System.out.println("用户名不能是空");
                continue;
            }
            if (!UserName.matches("[_0-9a-zA-Z]+")){
                System.out.println("用户名必须由数字字母或下划线组成");
                continue;
            }
            if(Character.isDigit(UserName.charAt(0))){
                System.out.println("用户名第一个字符不能是数字");
                continue;
            }
            break;
        }
        while(true){
            System.out.println("请输入密码（不能为空，密码长度至少8位，由字母、数字、下划线组成）");
            PassWord = scanner.next();
            if(PassWord == null){
                System.out.println("密码不能为空");
                continue;
            }
            if(PassWord.length()<8){
                System.out.println("密码长度至少8位");
                continue;
            }
            if(!PassWord.matches("[_0-9a-zA-Z]+")){
                System.out.println("密码只能由数字字母和下划线组成");
                continue;
            }
            break;
        }
        while(true){
            System.out.println("请输入邮箱（不能为空，需包含”@”符号。）");
            Email = scanner.next();
            if(Email == null){
                System.out.println("邮箱不能为空");
                continue;
            }
            if(!Email.contains("@")){
                System.out.println("需要包含'@'");
                continue;
            }
            if(!Email.matches(".+@.+")){
                System.out.println("”@”符号前后均需有内容");
                continue;
            }
            if(!Email.matches(".+@([a-zA-Z]+)+(\\.([a-zA-Z]+)+)+")){
                System.out.println("”@”符号后需要出现多个由”.”分割的词");
                continue;
            }
            break;
        }
        System.out.println("用户名："+UserName+
                            "密码："+PassWord+
                            "邮箱："+Email);
    }
}
