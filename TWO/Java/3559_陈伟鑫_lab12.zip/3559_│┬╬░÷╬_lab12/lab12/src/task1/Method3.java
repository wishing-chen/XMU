package task1;

import java.util.concurrent.Executor;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class Method3 implements Runnable{
    @Override
    public void run()
    {
        for(int i=1;i<=10;i++)
            System.out.println(Thread.currentThread().getName()+"-"+i);
    }

    public static void main(String[] args)
    {
        ExecutorService executorService = Executors.newCachedThreadPool();
        executorService.submit(new Method3());
        executorService.submit(new Method3());

        executorService.shutdown();
    }
}
