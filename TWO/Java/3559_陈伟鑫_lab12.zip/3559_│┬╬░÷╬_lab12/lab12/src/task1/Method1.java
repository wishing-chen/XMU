package task1;

public class Method1 extends Thread{
    Method1(String name) {super(name);}

    @Override
    public void run()
    {
        for(int i=1;i<=10;i++)
            System.out.println(Thread.currentThread().getName()+"-"+i);
    }

    public static void main(String[] args)
    {
        Thread thread1 = new Method1("thread1");
        Thread thread2 = new Method1("thread2");

        thread1.start();
        thread2.start();
    }
}
