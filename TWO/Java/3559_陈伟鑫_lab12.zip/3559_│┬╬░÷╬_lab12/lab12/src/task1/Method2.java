package task1;

public class Method2 implements Runnable{

    @Override
    public void run() {
        for(int i=1;i<=10;i++)
            System.out.println(Thread.currentThread().getName()+"-"+i);
    }

    public static void main(String[] args)
    {
        Runnable runnable1 = new Method2();
        Runnable runnable2 = new Method2();

        Thread thread1 = new Thread(runnable1,"thread1");
        Thread thread2 = new Thread(runnable2,"thread2");

        thread1.start();
        thread2.start();
    }
}
