package task3;

public class Test2 {
    public static void main(String[] args)
    {
        Buffer buffer = new Buffer();
        Runnable runnable1 = new BufferRead(buffer);
        Runnable runnable2 = new BufferWrite(buffer);

        Thread thread1 = new Thread(runnable1,"Thread1");
        Thread thread2 = new Thread(runnable2,"Thread2");

        thread1.start();
        thread2.start();
    }
}
