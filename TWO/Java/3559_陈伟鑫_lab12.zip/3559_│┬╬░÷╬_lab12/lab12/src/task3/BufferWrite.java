package task3;

import java.security.SecureRandom;

public class BufferWrite implements Runnable{
    private Buffer buffer;
    BufferWrite(Buffer buffer){this.buffer = buffer;}
    @Override
    public void run()
    {
        while(true)
        {
            SecureRandom secureRandom = new SecureRandom();
            int random = secureRandom.nextInt(10) + 1;
            try {
                buffer.write(random);
            } catch (InterruptedException e) {
                break;
            }
        }
    }
}
