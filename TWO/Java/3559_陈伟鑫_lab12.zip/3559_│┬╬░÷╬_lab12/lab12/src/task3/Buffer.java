package task3;

public class Buffer {
    private int[] buffer = new int[4];
    private int head;
    private int tail;
    private int size;

    public synchronized void write(int data) throws InterruptedException {
        while(size==buffer.length)
            wait();
        buffer[head] = data;
        System.out.println(Thread.currentThread().getName()+" write "+ data);
        head = (head+1)%buffer.length;
        size++;
        notifyAll();
    }
    public synchronized void read() throws InterruptedException {
        while(size==0)
            wait();
        while(size!=0)
        {
            System.out.println(Thread.currentThread().getName()+" read "+tail+" "+buffer[tail]);
            tail = (tail+1)%buffer.length;
            size--;
        }
        notifyAll();
    }
}
