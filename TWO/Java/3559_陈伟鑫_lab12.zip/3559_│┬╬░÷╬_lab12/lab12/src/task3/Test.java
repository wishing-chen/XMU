package task3;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class Test{
    public static void main(String[] args)
    {
        Buffer buffer = new Buffer();
        ExecutorService executorService = Executors.newCachedThreadPool();
        executorService.execute(new BufferWrite(buffer));
        executorService.execute(new BufferRead(buffer));
        executorService.shutdown();
    }
}
