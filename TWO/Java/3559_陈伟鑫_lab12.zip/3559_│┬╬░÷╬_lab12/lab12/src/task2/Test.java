package task2;

import java.util.concurrent.Executor;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class Test{
    private static int[] number = new int[10000];

    public static void main(String[] args)
    {
        ExecutorService executorService = Executors.newCachedThreadPool();
        executorService.execute(new Number(1,10));
        executorService.execute(new Number(100,1000));
        executorService.execute(new Number(2000,3000));
        executorService.execute(new Number(4000,5000));

        executorService.shutdown();
    }
    public static class Number implements Runnable{
        private int start;
        private int end;

        Number(int start,int end)
        {
            this.start = start;
            this.end = end;
        }

        @Override
        public void run()
        {
            for(int i=start;i<=end;i++) {
                number[i - 1] = i;
                System.out.println(Thread.currentThread().getName()+" is writing "+i);
            }
        }
    }
}
