module org.example.final_exam {
    requires javafx.controls;
    requires javafx.fxml;


    opens org.example.final_exam to javafx.fxml;
    exports org.example.final_exam;
}