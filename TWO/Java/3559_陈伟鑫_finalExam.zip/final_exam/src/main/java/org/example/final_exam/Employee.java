package org.example.final_exam;

public class Employee {
    private int id;
    private String name;
    private String dept;
    private int level;

    Employee(int id,String name,String dept,int level)
    {
        this.id = id;
        this.name = name;
        this.dept = dept;
        this.level = level;
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getDept() {
        return dept;
    }

    public int getLevel() {
        return level;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setDept(String dept) {
        this.dept = dept;
    }

    public void setLevel(int level) {
        this.level = level;
    }

    @Override
    public String toString()
    {
        // 使得listview显示的是id而不是对象的属性信息
        return ""+id;
    }
}