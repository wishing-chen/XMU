package org.example.final_exam;

import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

public class Test extends Application {
    private ObservableList<Employee> employees = FXCollections.observableArrayList();
    private ListView<Employee> listView = new ListView<>(employees);;
    private TextField idField, nameField, deptField, levelField;
    private Button addButton, saveButton, deleteButton, saveToFileButton;
    private Label idLabel,nameLabel,deptLabel,levelLabel;

    @Override
    public void start(Stage stage) {
        // 放需要输入的信息和输入框
        idLabel = new Label("ID：         ");
        nameLabel = new Label("姓名：      ");
        deptLabel = new Label("部门：      ");
        levelLabel = new Label("岗位级别：");
        idField = new TextField();
        nameField = new TextField();
        deptField = new TextField();
        levelField = new TextField();

        // 水平布局 将label和textField联系起来
        HBox idBox = new HBox(10);
        idBox.getChildren().addAll(idLabel,idField);
        HBox nameBox = new HBox(10);
        nameBox.getChildren().addAll(nameLabel,nameField);
        HBox deptBox = new HBox(10);
        deptBox.getChildren().addAll(deptLabel,deptField);
        HBox levelBox = new HBox(10);
        levelBox.getChildren().addAll(levelLabel,levelField);

        // 垂直布局 将输入框垂直摆放
        VBox infoBox = new VBox(60);
        infoBox.setPadding(new Insets(30,0,0,0));
        infoBox.getChildren().addAll(idBox,nameBox,deptBox,levelBox);

        addButton = new Button("新增");
        saveButton = new Button("保存");
        deleteButton = new Button("删除");
        saveToFileButton = new Button("保存至文件");

        // 水平布局 放按钮
        HBox buttonBox = new HBox(30);
        buttonBox.setPadding(new Insets(0,0,0,120));
        buttonBox.getChildren().addAll(addButton,saveButton,deleteButton,saveToFileButton);

        // 水平布局 将listview和infoBox放一起
        HBox hBox = new HBox(30);
        hBox.setPadding(new Insets(0,0,0,10));
        hBox.getChildren().addAll(listView,infoBox);

        // 垂直布局 将上面的listview和info 与 下面的button
        VBox vbox = new VBox(20);
        vbox.setPadding(new Insets(0,0,20,0));
        vbox.getChildren().addAll(hBox,buttonBox);

        Scene scene = new Scene(vbox, 600, 400);
        stage.setScene(scene);
        stage.setTitle("员工信息管理");
        stage.show();

        // 按钮监听
        listView.getSelectionModel().selectedItemProperty().addListener((observable, oldValue, newValue) -> display(newValue));
        addButton.setOnAction(actionEvent -> addEmployee());
        saveButton.setOnAction(actionEvent -> saveEmployee());
        deleteButton.setOnAction(actionEvent -> deleteEmployee());
        saveToFileButton.setOnAction(actionEvent -> {
            try {
                saveToFile();
            } catch (IOException ex) {
                throw new RuntimeException(ex);
            }
        });
    }

    public void display(Employee employee) {
        idField.setText(String.valueOf(employee.getId()));
        nameField.setText(employee.getName());
        deptField.setText(employee.getDept());
        levelField.setText(String.valueOf(employee.getLevel()));
    }

    public void addEmployee() {
        Employee employee = new Employee(0, "", "", 0);
        employees.add(employee);
        // 新增后 自动选择新增的员工
        listView.getSelectionModel().select(employee);
    }

    public void saveEmployee() {
        // 监听到选择的员工，并根据右侧Field的信息重新修改员工信息
        Employee selectedEmployee = listView.getSelectionModel().getSelectedItem();
        selectedEmployee.setId(Integer.parseInt(idField.getText()));
        selectedEmployee.setName(nameField.getText());
        selectedEmployee.setDept(deptField.getText());
        selectedEmployee.setLevel(Integer.parseInt(levelField.getText()));
        listView.refresh();
    }

    public void deleteEmployee() {
        // 获得所选员工 直接删除员工 并清空文本框
        employees.remove(listView.getSelectionModel().getSelectedItem());
        idField.clear();
        nameField.clear();
        deptField.clear();
        levelField.clear();
    }

    public void saveToFile() throws IOException {
        // 获得当前文件路径 并指定到resources文件夹下
        Path filePath = Paths.get(Paths.get("").toAbsolutePath() +"/src/main/resources","employeesData.txt");
        File file = new File(filePath.toString());
        // 如果已经存在 则删除原文件 并写入新文件
        if (file.exists())
            file.delete();
        Files.createFile(filePath);
        TextArea temp = new TextArea(); // 暂存需要写入的内容
        for(Employee items : listView.getItems()) //遍历并格式化写入
            temp.appendText("ID："+items.getId()+
                    "\t姓名："+items.getName()+
                    "\t部门: "+items.getDept()+
                    "\t岗位级别："+items.getLevel()+"\n");
        Files.writeString(filePath,temp.getText());
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setContentText("内容已保存到文件！");
        alert.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
