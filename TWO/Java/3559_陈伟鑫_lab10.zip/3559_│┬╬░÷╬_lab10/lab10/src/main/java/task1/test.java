package task1;

import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.geometry.Orientation;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.text.Text;
import javafx.stage.Stage;

import java.io.IOException;

public class test extends Application {
    @Override
    public void start(Stage stage) throws IOException {
        ToggleGroup toggleGroup = new ToggleGroup();
        RadioButton highRadioButton = new RadioButton("High");
        RadioButton mediumRadioButton = new RadioButton("Medium");
        RadioButton lowRadioButton = new RadioButton("Low");
        highRadioButton.setToggleGroup(toggleGroup);
        mediumRadioButton.setToggleGroup(toggleGroup);
        lowRadioButton.setToggleGroup(toggleGroup);
        highRadioButton.setSelected(true);
        VBox vBox1 = new VBox(5);
        vBox1.getChildren().addAll(highRadioButton,mediumRadioButton,lowRadioButton);

        TextField account = new TextField("your name");
        TextField password = new TextField("your password");
        VBox vBox2 = new VBox(5);
        vBox2.getChildren().addAll(account,password);

        ObservableList<String> options = FXCollections.observableArrayList("English","Chinese","Japanese","Germany");
        ComboBox<String> comboBox = new ComboBox<>(options);
        comboBox.setValue("English");
        StackPane stackPane3 = new StackPane(comboBox);
        stackPane3.setPadding(new Insets(20,0,0,0));
        HBox hBox1 = new HBox(5);
        hBox1.setPadding(new Insets(20, 0, 0, 10));
        hBox1.getChildren().addAll(vBox1,vBox2,stackPane3);

        Button acceptButton = new Button("Accept");
        Button declineButton = new Button("Decline");
        Text text1 = new Text("Not Available");
        StackPane stackPane1 = new StackPane(text1);
        stackPane1.setBorder(new Border(new BorderStroke(null, BorderStrokeStyle.DASHED, null, new BorderWidths(1))));
        HBox hBox2 = new HBox(20);
        hBox2.setPadding(new Insets(0, 0, 0, 10));
        hBox2.getChildren().addAll(acceptButton,declineButton,stackPane1);

        CheckBox normal = new CheckBox("Normal");
        CheckBox checked = new CheckBox("Checked");
        CheckBox undefined = new CheckBox("Undefined");
        Separator separator = new Separator();
        separator.setOrientation(Orientation.VERTICAL);
        checked.setSelected(true);
        undefined.setIndeterminate(true);
        HBox hBox3 = new HBox(20);
        hBox3.setPadding(new Insets(0, 0, 0, 10));
        hBox3.getChildren().addAll(normal,separator,checked,undefined);

        Text text2 = new Text("Progress:");
        StackPane stackPane2 = new StackPane(text2);
        stackPane2.setBorder(new Border(new BorderStroke(null, BorderStrokeStyle.DASHED, null, new BorderWidths(1))));
        Slider slider = new Slider();
        Circle circle = new Circle(10, Color.RED);
        Text text3 = new Text("0%");
        VBox vBox3 = new VBox(5);
        vBox3.getChildren().addAll(circle,text3);
        HBox hBox4 = new HBox(10);
        hBox4.setPadding(new Insets(0, 0, 0, 10));
        hBox4.getChildren().addAll(stackPane2,slider,vBox3);

        VBox vBox = new VBox(10);
        vBox.getChildren().addAll(hBox1,hBox2,hBox3,hBox4);

        //Scene scene = new Scene(fxmlLoader.load(), 320, 240);
        Scene scene = new Scene(vBox,400,240);
        stage.setTitle("Demo");
        stage.setScene(scene);
        stage.show();
    }

    public static void main(String[] args) {
        launch();
    }
}