package task2;

// Fig. 13.6: PainterController.java
// Controller for the Painter app
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.RadioButton;
import javafx.scene.control.ToggleGroup;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.paint.Paint;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Line;
import javafx.scene.shape.Rectangle;
import javafx.stage.Stage;

import java.io.IOException;

public class PainterController {

    // enum representing pen sizes
    private enum PenSize {
        SMALL(2),
        MEDIUM(4),
        LARGE(6);

        private final int radius;

        PenSize(int radius) {this.radius = radius;}

        public int getRadius() {return radius;}
    }
    private enum PenShape{
        CIRCLE(1),
        RECTANGLE(2),
        LINE(3);

        private final int shape;

        PenShape(int i) { shape = i;}

        public int getShape() {return shape;}
    }

    // instance variables that refer to GUI components
    @FXML private RadioButton blackRadioButton;
    @FXML private RadioButton redRadioButton;
    @FXML private RadioButton greenRadioButton;
    @FXML private RadioButton blueRadioButton;
    @FXML private RadioButton customizeRadioButton;
    @FXML private RadioButton smallRadioButton;
    @FXML private RadioButton mediumRadioButton;
    @FXML private RadioButton largeRadioButton;
    @FXML private RadioButton circleRadioButton;
    @FXML private RadioButton rectangleRadioButton;
    @FXML private RadioButton lineRadioButton;
    @FXML private Pane drawingAreaPane;
    @FXML private ToggleGroup colorToggleGroup;
    @FXML private ToggleGroup sizeToggleGroup;
    @FXML private ToggleGroup shapeToggleGroup;

    // instance variables for managing Painter state
    private PenSize radius = PenSize.MEDIUM; // radius of circle
    private Paint brushColor = Color.BLACK; // drawing color
    private PenShape shape = PenShape.CIRCLE;
    private double startX,startY;

    // set user data for the RadioButtons
    public void initialize() {
        // user data on a control can be any Object
        blackRadioButton.setUserData(Color.BLACK);
        redRadioButton.setUserData(Color.RED);
        greenRadioButton.setUserData(Color.GREEN);
        blueRadioButton.setUserData(Color.BLUE);
        customizeRadioButton.setUserData("default");
        smallRadioButton.setUserData(PenSize.SMALL);
        mediumRadioButton.setUserData(PenSize.MEDIUM);
        largeRadioButton.setUserData(PenSize.LARGE);
        circleRadioButton.setUserData(PenShape.CIRCLE);
        rectangleRadioButton.setUserData(PenShape.RECTANGLE);
        lineRadioButton.setUserData(PenShape.LINE);
    }
    @FXML
    private void drawingAreaMousePressed(MouseEvent e){
        startX = e.getX();
        startY = e.getY();
    }
    @FXML
    private void drawingAreaMouseReleased(MouseEvent e){
        if(shape == PenShape.RECTANGLE)
        {
            double width = e.getX() - startX;
            double height = e.getY() - startY;

            Rectangle newRectangle = new Rectangle(startX, startY, width, height);
            newRectangle.setFill(Color.TRANSPARENT);
            newRectangle.setStroke(brushColor);
            newRectangle.setStrokeWidth(radius.getRadius());

            drawingAreaPane.getChildren().add(newRectangle);
        }
        else if(shape == PenShape.LINE)
        {
            Line newLine = new Line(startX,startY,e.getX(),e.getY());
            newLine.setFill(brushColor);
            newLine.setStroke(brushColor);
            newLine.setStrokeWidth(radius.getRadius());

            drawingAreaPane.getChildren().add(newLine);
        }
    }
    // handles drawingArea's onMouseDragged MouseEvent
    @FXML
    private void drawingAreaMouseDragged(MouseEvent e) {
        if(shape == PenShape.CIRCLE) {
            Circle newCircle = new Circle(e.getX(), e.getY(),
                    radius.getRadius(), brushColor);
            drawingAreaPane.getChildren().add(newCircle);
        }
    }
    // handles color RadioButton's ActionEvents
    @FXML
    private void colorRadioButtonSelected(ActionEvent e) throws IOException {
        // user data for each color RadioButton is the corresponding Color
        if(colorToggleGroup.getSelectedToggle().getUserData() instanceof Color)
            brushColor = (Color)colorToggleGroup.getSelectedToggle().getUserData();
        else{
            FXMLLoader loader = new FXMLLoader(getClass().getResource("Color.fxml"));
            Parent colorRoot = loader.load();
            Scene colorScene = new Scene(colorRoot);
            Stage colorStage = new Stage();
            colorStage.setScene(colorScene);
            colorStage.showAndWait();
            ColorController colorController = loader.getController();
            brushColor = colorController.getSelectedColor();
        }
    }

    // handles size RadioButton's ActionEvents
    @FXML
    private void sizeRadioButtonSelected(ActionEvent e) {
        // user data for each size RadioButton is the corresponding PenSize
        radius =
                (PenSize) sizeToggleGroup.getSelectedToggle().getUserData();
    }

    @FXML
    private void shapeRadioButtonSelected(ActionEvent e) {
        // user data for each shape RadioButton is the corresponding PenShape
        shape =
                (PenShape) shapeToggleGroup.getSelectedToggle().getUserData();
    }

    // handles Undo Button's ActionEvents
    @FXML
    private void undoButtonPressed(ActionEvent event) {
        int count = drawingAreaPane.getChildren().size();

        // if there are any shapes remove the last one added
        if (count > 0) {
            drawingAreaPane.getChildren().remove(count - 1);
        }
    }

    // handles Clear Button's ActionEvents
    @FXML
    private void clearButtonPressed(ActionEvent event) {
        drawingAreaPane.getChildren().clear(); // clear the canvas
    }
}


/***********************************************************************
 (C) Copyright 1992-2018 by Deitel & Associates, Inc. and               *
 Pearson Education, Inc. All Rights Reserved.                           *
 <p>
 DISCLAIMER: The authors and publisher of this book have used their     *
 best efforts in preparing the book. These efforts include the          *
 development, research, and testing of the theories and programs        *
 to determine their effectiveness. The authors and publisher make       *
 no warranty of any kind, expressed or implied, with regard to these    *
 programs or to the documentation contained in these books. The authors *
 and publisher shall not be liable in any event for incidental or       *
 consequential damages in connection with, or arising out of, the       *
 furnishing, performance, or use of these programs.                     *
 */
