package task2;

abstract class Graph {
    abstract int calculateArea();
}
