package task2;

public class Triangle extends Graph{
    private int a;
    private int b;
    private int c;
    Triangle(){}
    Triangle(int a,int b,int c)
    {
        this.a = a;
        this.b = b;
        this.c = c;
    }
    @Override
    public int calculateArea()
    {
        double p = (double) (a + b + c) /2;
        return (int)Math.sqrt(p*(p-a)*(p-b)*(p-c));
    }
}
