package task2;
import java.util.Scanner;

public class Test {

    public static void main(String[] args)
    {
        Scanner scanner = new Scanner(System.in);
        int n = scanner.nextInt();
        String temp = scanner.nextLine();
        for(int i=0;i<n;i++){
            String str = scanner.nextLine();
            String[] data = str.split(" ");
            if(data.length == 2){
                Graph rectangle = new Rectangle(Integer.parseInt(data[0]),Integer.parseInt(data[1]));
                System.out.println(rectangle.calculateArea());
            }
            else if(data.length == 3){
                Graph triangle = new Triangle(Integer.parseInt(data[0]),Integer.parseInt(data[1]),Integer.parseInt(data[2]));
                System.out.println(triangle.calculateArea());
            }
        }
    }
}
