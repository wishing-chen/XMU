package task2;

public class Rectangle extends Graph{
    private int wide;
    private int height;
    Rectangle(){}
    Rectangle(int wide, int height)
    {
        this.wide = wide;
        this.height = height;
    }
    public void setWide(){System.out.println(1);}
    @Override
    public int calculateArea()
    {
        return wide * height;
    }
}
