package task1;

public class Test {
    public static void main(String[] args) {
        Vehicle vehicle = new Vehicle();
        Vehicle motor = new Motor();
        Vehicle ship = new Ship();
        Vehicle aeroplane = new Aeroplane();
        Vehicle bus = new Bus();
        Vehicle car = new Car();

        vehicle.run();
        motor.run();
        ship.run();
        aeroplane.run();
        bus.run();
        car.run();
    }
}