package task1;

public class Car extends Motor{
    @Override
    public void run()
    {
        System.out.println("这是轿车run方法");
    }
}
