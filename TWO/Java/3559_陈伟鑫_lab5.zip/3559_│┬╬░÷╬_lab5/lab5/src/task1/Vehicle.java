package task1;

public class Vehicle {
    public void run()
    {
        System.out.println("这是交通工具run方法");
    }
}
