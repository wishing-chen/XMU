package task1;

public class Aeroplane extends Vehicle{
    @Override
    public void run()
    {
        System.out.println("这是飞机run方法");
    }
}
