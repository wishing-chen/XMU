package task1;

public class Motor extends Vehicle{
    @Override
    public void run() {
        System.out.println("这是汽车run方法");
    }
}
