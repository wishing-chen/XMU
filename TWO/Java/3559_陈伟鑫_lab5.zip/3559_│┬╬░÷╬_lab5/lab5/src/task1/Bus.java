package task1;

public class Bus extends Motor{
    @Override
    public void run() {
        System.out.println("这是公共汽车run方法");
    }
}
