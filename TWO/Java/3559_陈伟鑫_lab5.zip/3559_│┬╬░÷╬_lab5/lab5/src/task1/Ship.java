package task1;

public class Ship extends Vehicle{
    @Override
    public void run() {
        System.out.println("这是轮船run方法");
    }
}
