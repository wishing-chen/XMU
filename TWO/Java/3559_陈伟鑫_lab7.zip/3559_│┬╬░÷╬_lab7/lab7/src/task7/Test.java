package task7;

public class Test {
    public static void main(String[] args)
    {
        CompensationModel[] compensationModels = {
            new SalariedCompensationModel(2),
            new CommissionCompensationModel(2.3,5.2),
            new HourlyCompensationModel(1,2),
            new BasePlusCommissionCompensationMode(3.2,6.5,2.3)
        };
        for(CompensationModel e:compensationModels)
            System.out.println(e.earnings());
    }
}
