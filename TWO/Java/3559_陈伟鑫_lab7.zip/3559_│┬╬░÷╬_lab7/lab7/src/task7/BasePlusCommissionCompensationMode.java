package task7;

public class BasePlusCommissionCompensationMode extends CommissionCompensationModel{

    private double baseSalary;

    BasePlusCommissionCompensationMode(double grossSales, double commissionRate,double baseSalary) {
        super(grossSales, commissionRate);
        this.baseSalary = baseSalary;
    }

    @Override
    public double earnings() {
        return getCommissionRate() * getGrossSales() + baseSalary;
    }
}
