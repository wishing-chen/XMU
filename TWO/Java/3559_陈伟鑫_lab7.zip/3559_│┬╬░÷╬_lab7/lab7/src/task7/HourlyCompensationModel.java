package task7;

public class HourlyCompensationModel implements CompensationModel{
    private double wage;
    private double hours;

    HourlyCompensationModel(double wage,double hours)
    {
        this.wage = wage;
        this.hours = hours;
    }
    @Override
    public double earnings() {
        return wage * hours;
    }
}
