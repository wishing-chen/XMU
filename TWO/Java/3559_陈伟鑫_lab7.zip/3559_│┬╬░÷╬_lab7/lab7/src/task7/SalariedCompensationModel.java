package task7;

public class SalariedCompensationModel implements CompensationModel{
    private double weeklySalary;

    SalariedCompensationModel(double weeklySalary)
    {
        this.weeklySalary = weeklySalary;
    }
    @Override
    public double earnings() {
        return weeklySalary;
    }
}
