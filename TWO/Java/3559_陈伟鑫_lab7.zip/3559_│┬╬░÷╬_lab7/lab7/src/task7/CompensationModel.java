package task7;

interface CompensationModel {
    double earnings();
}
