package task3;

public class ExceptionTest {
    public static void someMethod() throws Exception
    {
        throw new Exception("ERROR Test");
    }
    public static void someMethod2() throws Exception
    {
        try{
            someMethod();
        }
        catch (Exception e){
            throw e;
        }
    }
    public static void main(String[] args)
    {
        try{
            someMethod2();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
