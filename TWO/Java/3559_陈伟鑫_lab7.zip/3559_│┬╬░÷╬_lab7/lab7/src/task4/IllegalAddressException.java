package task4;

public class IllegalAddressException extends Exception{
    IllegalAddressException(String message)
    {
        super(message);
    }
}
