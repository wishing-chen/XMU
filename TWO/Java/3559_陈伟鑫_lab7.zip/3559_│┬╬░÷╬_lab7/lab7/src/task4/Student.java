package task4;

public class Student {
    private String name;
    private String address;
    public void setName(String name) throws IllegalNameException
    {
        if(name == null || name.isEmpty() ||name.length()>5)
            throw new IllegalNameException("名字长度必须在1-5之间");
        this.name = name;
    }
    public void setAddress(String address) throws IllegalAddressException
    {
        if(!(address.contains("市") || address.contains("省")))
            throw new IllegalAddressException("地址必须包含市或省");
        this.address = address;
    }
    public String getName(){return name;}
    public String getAddress(){return address;}
}
