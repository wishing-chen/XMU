package task4;

public class IllegalNameException extends Exception{
    IllegalNameException(String message)
    {
        super(message);
    }
}
