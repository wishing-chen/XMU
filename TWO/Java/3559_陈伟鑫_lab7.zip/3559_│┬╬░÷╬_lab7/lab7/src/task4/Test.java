package task4;

import java.util.Scanner;

public class Test {
    public static void main(String[] args)
    {
        Student student = new Student();
        Scanner scanner = new Scanner(System.in);
        while(true)
        {
            try {
                String name = scanner.nextLine();
                student.setName(name);
            } catch (IllegalNameException e) {
                System.err.println("名字输入有误：" + e.getMessage());
                continue;
            }
            break;
        }
        while(true)
        {
            try {
                String address = scanner.nextLine();
                student.setAddress(address);
            } catch (IllegalAddressException e) {
                System.err.println("地址输入有误：" + e.getMessage());
                continue;
            }
            break;
        }
        System.out.println("姓名："+student.getName()+" 地址："+student.getAddress());
    }
}
