package task2;

public class Test {
    public static void main(String[] args)
    {
        try{
        SomeClass someClass = new SomeClass(-1);}
        catch (IllegalArgumentException e){
            System.err.println("ERROR:"+e.getMessage());
        }
    }
}
