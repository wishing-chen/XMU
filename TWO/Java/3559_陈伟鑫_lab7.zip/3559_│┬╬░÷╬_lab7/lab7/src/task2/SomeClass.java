package task2;

public class SomeClass {
    private int value;
    SomeClass(int value) throws IllegalArgumentException
    {
        if(value < 0)
        {
            throw new IllegalArgumentException("value must be non-negative");
        }
        this.value = value;
    }
}
