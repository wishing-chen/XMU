package task5;

public class Equal {
        public static <T> boolean isEqualsTo(T obj1,T obj2)
        {
            return obj1.equals(obj2);
        }
        public static void main(String[] args)
        {
            int a = 1;
            int b = 2;
            int c = 2;
            System.out.println(isEqualsTo(a,b));
            System.out.println(isEqualsTo(b,c));
            String str1 = "java";
            String str2 = "java";
            System.out.println(isEqualsTo(str1,str2));
            System.out.println(isEqualsTo(str1,a));
        }
}
