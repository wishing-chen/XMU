package task6;

public class Test {
    public static void main(String[] args)
    {
        Pair<String, Integer> pair1 = new Pair<>();
        pair1.setElement1("Hello");
        pair1.setElement2(2);
        System.out.println(pair1.getElement1()+pair1.getElement2());

        Pair<Double, Boolean> pair2 = new Pair<>();
        pair2.setElement1(3.1415926);
        pair2.setElement2(false);
        System.out.println(pair2.getElement1()+" "+pair2.getElement2());
    }
}
