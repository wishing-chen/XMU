package task6;

public class Pair<F,S> {
    private F element1;
    private S element2;
    public void setElement1(F element1)
    {
        this.element1 = element1;
    }
    public void setElement2(S element2)
    {
        this.element2 = element2;
    }
    public F getElement1()
    {
        return element1;
    }
    public S getElement2()
    {
        return element2;
    }
}
