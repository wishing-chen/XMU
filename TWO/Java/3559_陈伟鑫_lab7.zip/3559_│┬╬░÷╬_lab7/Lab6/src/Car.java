public class Car extends Vehicle{
    int carLoad;
    String num;
    Car(String brand,String color,int carLoad,String outYear,String num) {
        super(brand,color,outYear);
        this.carLoad = carLoad;
        this.num = num;
    }
    @Override
    public void display(){
        System.out.println("小汽车，品牌："+brand+" 颜色:"+color+" 出厂年份:"+outYear+" 载客量"+carLoad+"人 厢数"+num);
    }
    @Override
    public String getName()
    {
        return "小汽车";
    }

}
