public class Vehicle {
    String brand;
    String color;
    String outYear;
    Vehicle(String brand, String color, String outYear)
    {
        this.brand = brand;
        this.color = color;
        this.outYear = outYear;
    }
    public void display(){}
    public String getName(){return "Vehicle";}
}
