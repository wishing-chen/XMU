public class Test {
    public static void main(String[] args)
    {
        Main test = new Main();
        test.home();
    }
}
