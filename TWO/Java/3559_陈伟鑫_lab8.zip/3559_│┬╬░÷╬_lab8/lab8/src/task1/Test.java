package task1;

import java.util.HashSet;
import java.util.Set;
import java.util.Scanner;

public class Test {
    public static void main(String[] args)
    {
        Scanner scanner = new Scanner(System.in);
        Set<String> nameSet = new HashSet<>();
        System.out.println("请输入名字的个数");
        int n = scanner.nextInt();
        while(n!=0)
        {
            System.out.println("请输入名字");
            String name = scanner.next();
            nameSet.add(name);
            n--;
        }
        for(String e:nameSet)
            System.out.println(e);
    }
}
