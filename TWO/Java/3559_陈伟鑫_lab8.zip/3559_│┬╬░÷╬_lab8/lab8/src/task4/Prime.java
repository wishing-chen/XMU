package task4;

import java.util.HashSet;
import java.util.Scanner;
import java.util.Set;

public class Prime {
    public static void main(String[] args)
    {
        Set<Integer> prime = new HashSet<>();
        Scanner scanner = new Scanner(System.in);
        int n = scanner.nextInt();
        if(n<=1)
            System.out.println("no");
        else{
            System.out.print(n+": ");
            for(int i = 2;i<=n;i++)
                if(n%i==0) {
                    n/=i;
                    prime.add(i);
                    i--;
                }
        }
        for(int e:prime)
            System.out.print(e+" ");
    }
}
