package task2;

import java.util.*;

public class Test {
    public static void main(String[] args)
    {
        Scanner scanner = new Scanner(System.in);
        String temp = "[,.! ?]+";
        String input = scanner.nextLine();
        String[] sentence = input.split(temp);
        Map<String, Integer> wordMap = new HashMap<>();
        for(String e:sentence) {
            e = e.toLowerCase();
            if(!wordMap.containsKey(e))
                wordMap.put(e,1);
            else {
                int value = wordMap.get(e);
                wordMap.put(e,value+1);
            }
        }
        for(String e:wordMap.keySet())
            System.out.println(e+"："+wordMap.get(e));
    }
}
