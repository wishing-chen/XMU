import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {
    List<Vehicle> motorcade = new ArrayList<>(); //用户储存车队信息
    public void createVehicle() {
        Scanner scanner = new Scanner(System.in);
        while(true)
        {
            System.out.println("请输入车辆信息，示例：");
            System.out.println("\t小汽车 丰田 红色 4 2007 2厢");
            System.out.println("\t卡车 雷诺 红色 3.5 2008");
            System.out.println("结束新增，请输入end");
            String allInfo = scanner.nextLine();
            String[] info = allInfo.split(" ");
            if(allInfo.equals("end")) // 输入end则退出
                break;
            //输入6个信息 则判定为小汽车 并进行分析
            else if (info.length == 6) {
                if (!info[0].equals("小汽车")) {
                    System.out.println("第一应为卡车或小汽车");
                    continue;
                }
                int carLoad;
                try {
                    carLoad = Integer.parseInt(info[3]);
                } catch (Exception e) {
                    System.out.println("载客量应为整数");
                    System.out.println("\n创建不成功");
                    continue;
                }
                Vehicle car = new Car(info[1], info[2], Integer.parseInt(info[3]), info[4], info[5]);
                motorcade.add(car);
                System.out.println("创建成功\n");
                car.display();
                System.out.println();
            }
            // 输入5个信息 判定为卡车 并进行分析
            else if (info.length == 5) {
                if (!info[0].equals("卡车")) {
                    System.out.println("第一应为卡车或小汽车");
                    continue;
                }
                double lorryLoad;
                try{lorryLoad = Double.parseDouble(info[3]);}
                catch (Exception e){
                    System.out.println("载货量应为整数或小数");
                    System.out.println("\n创建不成功");
                    continue;
                }
                Vehicle lorry = new Lorry(info[1], info[2], Double.parseDouble(info[3]), info[4]);
                motorcade.add(lorry);
                System.out.println("创建成功\n");
                lorry.display();
                System.out.println();
            }
            // 输入信息太少 则直接创建失败
            else
                System.out.println("输入信息不完整\n创建失败！");
        }
    }
    public void see()
    {
        Scanner scanner = new Scanner(System.in);
        List<Vehicle> list = new ArrayList<>();
        while(true)
        {
            System.out.println("请按照“类型 商标 颜色 出厂年”的顺序输入条件，若条件为空用“null”代替，2个示例");
            System.out.println("小汽车 丰田 红色 2007");
            System.out.println("null 丰田 null null");
            System.out.println("输入end返回上级菜单");
            String allInfo = scanner.nextLine();
            String[] info = allInfo.split(" ");
            if(allInfo.equals("end"))
                break;
            boolean flag = false;
            // 如果输入4个信息 则开始查询 否则直接失败
            if(info.length==4) {
                for (Vehicle e : motorcade) {
                    if ((info[0].equals("null") || info[0].equals(e.getName())) &&
                            (info[1].equals("null") || info[1].equals(e.brand)) &&
                            (info[2].equals("null") || info[2].equals(e.color)) &&
                            (info[3].equals("null") || info[3].equals(e.outYear))) {
                        list.add(e);
                        flag = true;
                    }
                }
                System.out.println("\n搜索到"+list.size()+"辆车，信息如下");
                int count = 1;
                for(Vehicle e : list) {
                    System.out.print(count++ +".");
                    e.display();
                }
            }
            else
                System.out.println("输入信息不正确");
            if(!flag)
                System.out.println("没有搜索到相应的交通工具");
        }
    }
    public void display()
    {
        // 直接循环输出车队信息
        System.out.println("目前有"+motorcade.size()+"辆车信息如下：");
        int count = 1;
        for(Vehicle e:motorcade)
        {
            System.out.print(count++);
            e.display();
        }
    }
    public void home() {
        Scanner scanner = new Scanner(System.in);
        int choose = 5;
        boolean flag = true;
        while(flag){
            System.out.println("请输入对应输入进行相应菜单操作");
            System.out.println("1.\t\t新增车辆");
            System.out.println("2.\t\t查询车辆");
            System.out.println("3.\t\t列出所有车辆");
            System.out.println("4.\t\t结束程序");
            System.out.println("请输入1-4的整数");

            try{choose = scanner.nextInt();}
            catch(Exception e){
                String temp = scanner.nextLine();
            }
            finally{
                switch (choose){
                    case 1:createVehicle();break;
                    case 2:see();break;
                    case 3:display();break;
                    case 4:flag = false;
                    default:
                }
            }
        }
    }
}