public class Lorry extends Vehicle{
    double lorryLoad;
    Lorry(String brand,String color,double lorryLoad,String outYear){
        super(brand,color,outYear);
        this.lorryLoad = lorryLoad;
    }

    @Override
    public void display() {
        System.out.println("卡车，品牌："+brand+" 颜色："+color + " 出厂年份："+outYear+" 载货量："+lorryLoad+"吨");
    }

    public String getName()
    {
        return "卡车";
    }
}
