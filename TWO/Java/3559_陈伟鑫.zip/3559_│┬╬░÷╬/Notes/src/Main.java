import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.*;


public class Main extends Application {
    private File currentFile = null;
    private Stack<String> history;
    private Stack<String> future;
    private List<Integer> searchIndex;
    private Map<String,String> color;

    private boolean textChange = false;
    private boolean isUndo = false;
    private boolean isAuto = true;

    private String fontSize = "14";
    private String fontColor = "black";
    private String fontFamily = "Arial";

    @Override
    public void start(Stage stage) throws Exception{
        history = new Stack<>();
        future = new Stack<>();
        searchIndex = new ArrayList<>();
        stage.setTitle("记事本");
        // 文件
        MenuItem fileCreateItem = new MenuItem("新建");
        MenuItem fileOpenItem = new MenuItem("打开");
        MenuItem fileSaveItem = new MenuItem("保存");
        MenuItem fileSaveAsItem = new MenuItem("另存为");
        Menu fileMenu = new Menu("文件");
        fileMenu.getItems().addAll(fileCreateItem,fileOpenItem, fileSaveItem,fileSaveAsItem);// new SeparatorMenuItem(),
        // 编辑
        MenuItem editUndoItem = new MenuItem("撤销");
        MenuItem editRedoItem = new MenuItem("重做");
        MenuItem editFindItem = new MenuItem("查找");
        MenuItem editReplaceItem = new MenuItem("替换");
        Menu editMenu = new Menu("编辑");
        editMenu.getItems().addAll(editUndoItem, editRedoItem,editFindItem,editReplaceItem);
        // 格式
        Menu formatFamilyMenu = new Menu("字体样式");
        RadioMenuItem FamilyArial = new RadioMenuItem("Arial");
        RadioMenuItem FamilyTimesNewRoman = new RadioMenuItem("Times New Roman");
        RadioMenuItem FamilyHelvetica = new RadioMenuItem("Helvetica");
        RadioMenuItem FamilyVerdana = new RadioMenuItem("Verdana");
        RadioMenuItem FamilyComicSansMS = new RadioMenuItem("Comic Sans MS");
        RadioMenuItem FamilyImpact = new RadioMenuItem("Impact");
        RadioMenuItem FamilyLucidaSansUnicode = new RadioMenuItem("Lucida Sans Unicode");
        RadioMenuItem FamilyTahoma = new RadioMenuItem("Tahoma");
        RadioMenuItem FamilyTrebuchetMS = new RadioMenuItem("Trebuchet MS");
        RadioMenuItem FamilyCourierNew = new RadioMenuItem("CourierNew");

        FamilyArial.setSelected(true);
        formatFamilyMenu.getItems().addAll(FamilyArial,FamilyTimesNewRoman,FamilyHelvetica,FamilyVerdana,
                FamilyComicSansMS,FamilyImpact,FamilyLucidaSansUnicode,FamilyTahoma,FamilyTrebuchetMS,FamilyCourierNew);

        Menu formatSizeMenu = new Menu("字体大小");
        RadioMenuItem size8 = new RadioMenuItem("8");
        RadioMenuItem size9 = new RadioMenuItem("9");
        RadioMenuItem size10 = new RadioMenuItem("10");
        RadioMenuItem size11 = new RadioMenuItem("11");
        RadioMenuItem size12 = new RadioMenuItem("12");
        RadioMenuItem size14 = new RadioMenuItem("14");
        RadioMenuItem size16 = new RadioMenuItem("16");
        RadioMenuItem size18 = new RadioMenuItem("18");
        RadioMenuItem size20 = new RadioMenuItem("20");
        RadioMenuItem size22 = new RadioMenuItem("22");
        size14.setSelected(true);
        formatSizeMenu.getItems().addAll(size8,size9,size10,size11,size12,size14,size16,size18,size20,size22);

        Menu formatColorMenu = new Menu("字体颜色");
        color = new HashMap<>();
        color.put("红","red"); color.put("蓝","blue");
        color.put("黄","yellow"); color.put("绿","green");
        color.put("紫","purple"); color.put("粉","pink");
        color.put("黑","black"); color.put("白","white");
        RadioMenuItem red = new RadioMenuItem("红");
        RadioMenuItem blue = new RadioMenuItem("蓝");
        RadioMenuItem yellow = new RadioMenuItem("黄");
        RadioMenuItem green = new RadioMenuItem("绿");
        RadioMenuItem purple = new RadioMenuItem("紫");
        RadioMenuItem pink = new RadioMenuItem("粉");
        RadioMenuItem black = new RadioMenuItem("黑");
        RadioMenuItem white = new RadioMenuItem("白");
        black.setSelected(true);
        formatColorMenu.getItems().addAll(red,blue,yellow,green,purple,pink,white,black);

        RadioMenuItem formatAutoItem = new RadioMenuItem("自动换行");
        formatAutoItem.setSelected(true);

        Menu formatMenu = new Menu("格式");
        formatMenu.getItems().addAll(formatFamilyMenu,formatSizeMenu,formatColorMenu,formatAutoItem);

        // 最上层导航栏
        MenuBar menuBar = new MenuBar();
        menuBar.getMenus().addAll(fileMenu, editMenu,formatMenu);
        // 中层文本框
        TextArea textArea = new TextArea();
        textArea.setWrapText(true);
        // 底层状态栏
        HBox statusBar = new HBox();
        Separator separator = new Separator();
        separator.setOrientation(javafx.geometry.Orientation.VERTICAL);
        Label status = new Label("\t行：0\t列：0");
        Label code = new Label("\t\t\t\t\t\t\t\t\t\t\tUnicode");
        statusBar.getChildren().addAll(status,separator,code);
        // 布局
        BorderPane root = new BorderPane();
        root.setTop(menuBar);
        root.setCenter(textArea);
        root.setBottom(statusBar);

        //按钮监听
        fileCreateItem.setOnAction(event -> createFile(stage,textArea));
        fileOpenItem.setOnAction(actionevent -> openFile(stage,textArea));
        fileSaveItem.setOnAction(actionEvent -> saveFile(stage,textArea));
        fileSaveAsItem.setOnAction(actionEvent -> saveAsFile(stage,textArea));

        editUndoItem.setOnAction(actionEvent -> UndoEdit(textArea));
        editRedoItem.setOnAction(actionEvent -> RedoEdit(textArea));
        editFindItem.setOnAction(actionEvent -> findEdit(textArea));
        editReplaceItem.setOnAction(actionEvent -> replaceEdit(textArea));

        stage.setOnCloseRequest(event ->{
            createFile(stage,textArea);
        });
        formatAutoItem.setOnAction(actionEvent -> {
            if(isAuto) {
                textArea.setWrapText(false);
                isAuto = false;
            }
            else {
                textArea.setWrapText(true);
                isAuto = true;
            }
        });
        textArea.textProperty().addListener((observable, oldValue, newValue) -> {
            if(!newValue.equals(oldValue)) {
                textChange = true;
                if(!isUndo) {
                    if(history.size()>10)
                        history.removeFirst();
                    history.push(oldValue);
                }
                else
                    isUndo = false;
            }
        });

        // 字体样式
        ToggleGroup FamilyToggleGroup = new ToggleGroup();
        formatFamilyMenu.getItems().forEach(item -> {
            RadioMenuItem radioMenuItem = (RadioMenuItem) item;
            radioMenuItem.setToggleGroup(FamilyToggleGroup);
            radioMenuItem.setOnAction(event -> {
                fontFamily = radioMenuItem.getText();
                setTextStyle(textArea);
            });
        });

        // 字体大小
        ToggleGroup SizeToggleGroup = new ToggleGroup();
        formatSizeMenu.getItems().forEach(item -> {
            RadioMenuItem radioMenuItem = (RadioMenuItem) item;
            radioMenuItem.setToggleGroup(SizeToggleGroup);
            radioMenuItem.setOnAction(event -> {
                fontSize = radioMenuItem.getText();
                setTextStyle(textArea);
            });
        });

        // 字体颜色
        ToggleGroup ColorToggleGroup = new ToggleGroup();
        formatColorMenu.getItems().forEach(item -> {
            RadioMenuItem radioMenuItem = (RadioMenuItem) item;
            radioMenuItem.setToggleGroup(ColorToggleGroup);
            radioMenuItem.setOnAction(event -> {
                fontColor = color.get(radioMenuItem.getText());
                setTextStyle(textArea);
            });
        });

        // 鼠标点击
        textArea.setOnMouseClicked(event -> {
            int index = textArea.getCaretPosition();
            int line = getLine(index, textArea.getText());
            int column = getColumn(index, textArea.getText(), line);
            status.setText("\t行："+line+"\t"+" 列："+column);
        });

        // others
        Scene scene = new Scene(root, 600, 400);
        scene.getStylesheets().add(Objects.requireNonNull(getClass().getResource("styles.css")).toExternalForm());
        stage.setScene(scene);
        stage.show();
    }
    public static void main(String[] args){
        launch();
    }

    private void createFile(Stage stage,TextArea textArea) {
        // 判断文档是否修改过
        System.out.println(textArea.getText());
        if(textChange && !textArea.getText().isEmpty()){
            Dialog<ButtonType> dialog = new Dialog<>();
            dialog.setTitle("警告！");
            dialog.setContentText("文件未保存！");

            // 添加自定义按钮
            ButtonType saveButton = new ButtonType("保存", ButtonBar.ButtonData.OTHER);
            ButtonType noSaveButton = new ButtonType("不保存", ButtonBar.ButtonData.OTHER);
            ButtonType cancelButton = new ButtonType("取消", ButtonBar.ButtonData.CANCEL_CLOSE);
            dialog.getDialogPane().getButtonTypes().addAll(saveButton,noSaveButton,cancelButton);

            // 显示对话框并获取用户选择
            Optional<ButtonType> result = dialog.showAndWait();
            result.ifPresent(buttonType -> {
                if (buttonType == saveButton) {
                    if (saveFile(stage, textArea))
                        textArea.clear();
                }
                else if(buttonType == noSaveButton)
                    textArea.clear();
            });
        } else
            textArea.clear();
    }

    private void openFile(Stage stage,TextArea textArea) {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("选择文件");
        // 显示文件选择对话框，并获取用户选择的文件
        File selectedFile = fileChooser.showOpenDialog(stage);
        currentFile = selectedFile;
        String content = null;
        try {
            content = new String(Files.readAllBytes(Paths.get(selectedFile.getAbsolutePath())));
        } catch (IOException e) {
            e.printStackTrace();
        }
        textArea.setText(content);
    }

    private boolean saveFile(Stage stage,TextArea textArea) {
        if (currentFile == null) {
            return saveAsFile(stage,textArea);
        } else {
            // 将文本框中的内容写入到当前文件中
            try (BufferedWriter writer = new BufferedWriter(new FileWriter(currentFile))) {
                writer.write(textArea.getText());
            } catch (IOException e) {
                return false;
            }
            return true;
        }
    }

    private boolean saveAsFile(Stage stage,TextArea textArea) {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("另存为");
        // 显示文件保存对话框，并获取用户选择的文件
        File selectedFile = fileChooser.showSaveDialog(stage);
        if (selectedFile != null) {
            currentFile = selectedFile;
            // 将文本框中的内容写入到所选文件中
            try (BufferedWriter writer = new BufferedWriter(new FileWriter(selectedFile))) {
                writer.write(textArea.getText());
            } catch (IOException e) {
                return false;
            }
            return true;
        }
        return false;
    }

    private void UndoEdit(TextArea textArea){
        if (!history.isEmpty()) {
            isUndo = true;
            future.push(textArea.getText());
            String previousText = history.pop();
            textArea.setText(previousText);
        }
    }

    private void RedoEdit(TextArea textArea){
        if(!future.isEmpty()){
            String RedoText = future.pop();
            textArea.setText(RedoText);
        }
    }

    private void findEdit(TextArea textArea){
        final int[] currentIndex = {-1};
        VBox findVbox = new VBox();
        HBox buttonHbox = new HBox();
        TextArea findText = new TextArea();

        Button findPrevButton = new Button("查找上一个");
        Button findNextButton = new Button("查找下一个");
        findPrevButton.setDisable(true);

        buttonHbox.getChildren().addAll(findPrevButton,findNextButton);
        findVbox.getChildren().addAll(findText,buttonHbox);

        Scene findScene = new Scene(findVbox);
        Stage findStage = new Stage();

        findStage.setScene(findScene);
        findStage.show();

        findPrevButton.setOnAction(actionEvent -> {
            createSearchList(textArea, findText);
            if(currentIndex[0] > 0 && !searchIndex.isEmpty()) {
                if(currentIndex[0]-1==0)
                    findPrevButton.setDisable(true);
                currentIndex[0]--;
                textArea.selectRange(searchIndex.get(currentIndex[0]),searchIndex.get(currentIndex[0])+findText.getText().length());
                findNextButton.setDisable(false);
            }});
        findNextButton.setOnAction(actionEvent -> {
            createSearchList(textArea,findText);
            if(searchIndex.size()==1) {
                findPrevButton.setDisable(true);
                findNextButton.setDisable(true);
                System.out.println(searchIndex.getFirst());
                return;
            }
            if (currentIndex[0]<searchIndex.size() && !searchIndex.isEmpty()){
                if(currentIndex[0] + 1 == searchIndex.size()-1)
                    findNextButton.setDisable(true);
                currentIndex[0]++;
                textArea.selectRange(searchIndex.get(currentIndex[0]),searchIndex.get(currentIndex[0])+findText.getText().length());
                findPrevButton.setDisable(false);
            }
            else if(searchIndex.isEmpty()){
                Alert alert = new Alert(Alert.AlertType.WARNING);
                alert.setTitle("警告");
                alert.setHeaderText(null);
                alert.setContentText("查找内容不存在！");
                alert.showAndWait();
                findNextButton.setDisable(true);
            }
        });

        findText.textProperty().addListener((observable, oldValue, newValue) -> {
            if(!newValue.equals(oldValue)) {
                findNextButton.setDisable(false);
            }
        });
    }

    private void replaceEdit(TextArea textArea){
        int[] currentIndex={-1};
        TextArea replaceText = new TextArea();
        TextArea searchText = new TextArea();
        Button findPrevButton = new Button("查找上一个");
        Button findNextButton = new Button("查找下一个");
        Button replaceOneButton = new Button("替换一个");
        Button replaceAllButton = new Button("替换全部");
        Label searchLabel = new Label("请在下面输入需要替换的内容");
        Label replaceLabel = new Label("请在下面输入替换后的内容");
        VBox vBox = new VBox();
        HBox hBox = new HBox();
        hBox.getChildren().addAll(findPrevButton,findNextButton,replaceOneButton,replaceAllButton);
        vBox.getChildren().addAll(searchLabel,searchText,replaceLabel,replaceText,hBox);
        Scene scene = new Scene(vBox);
        Stage replaceStage = new Stage();
        replaceStage.setScene(scene);
        replaceStage.show();

        replaceOneButton.setDisable(true);
        findPrevButton.setDisable(true);

        replaceAllButton.setOnAction(actionEvent -> {
            String currentString = textArea.getText();
            String replaceString = replaceText.getText();
            String searchString = searchText.getText();
            textArea.setText(currentString.replace(searchString,replaceString));
        });

        findPrevButton.setOnAction(actionEvent -> {
            createSearchList(textArea, searchText);
            if(currentIndex[0] > 0 && !searchIndex.isEmpty()) {
                if(currentIndex[0]-1==0)
                    findPrevButton.setDisable(true);
                currentIndex[0]--;
                textArea.selectRange(searchIndex.get(currentIndex[0]),searchIndex.get(currentIndex[0])+searchText.getText().length());
                findNextButton.setDisable(false);
            }});
        findNextButton.setOnAction(actionEvent -> {
            createSearchList(textArea,searchText);
            if (currentIndex[0]<searchIndex.size() && !searchIndex.isEmpty()){
                if(currentIndex[0] + 1 == searchIndex.size()-1)
                    findNextButton.setDisable(true);
                currentIndex[0]++;
                textArea.selectRange(searchIndex.get(currentIndex[0]),searchIndex.get(currentIndex[0])+searchText.getText().length());
                replaceOneButton.setDisable(false);
                findPrevButton.setDisable(false);
            }
            if(searchIndex.size()==1)
                findPrevButton.setDisable(true);
            if(searchIndex.isEmpty()){
                Alert alert = new Alert(Alert.AlertType.WARNING);
                alert.setTitle("警告");
                alert.setHeaderText(null);
                alert.setContentText("查找内容不存在！");
                alert.showAndWait();
                findNextButton.setDisable(true);
            }
        });

        replaceOneButton.setOnAction(actionEvent -> {
            createSearchList(textArea,searchText);
            String temp1 = textArea.getText().substring(0,searchIndex.get(currentIndex[0]));
            String temp2 = textArea.getText().substring(searchIndex.get(currentIndex[0])+searchText.getText().length());
            textArea.setText(temp1+replaceText.getText()+temp2);
            searchIndex.remove(currentIndex[0]);
            if(!searchIndex.isEmpty())
                findPrevButton.setDisable(true);
            currentIndex[0] = -1;
            replaceOneButton.setDisable(true);
        });

        searchText.textProperty().addListener((observable, oldValue, newValue)->{
            if(!newValue.equals(oldValue))
                findNextButton.setDisable(false);
        });
    }

    private void createSearchList(TextArea textArea,TextArea findText) {
        String searchString = findText.getText();
        searchIndex.clear();
        String currentString = textArea.getText();
        int pastIndex = 0;
        while(true){
            int index = currentString.indexOf(searchString,pastIndex);
            if(index == -1) break;
            searchIndex.add(index);
            pastIndex = index + 1;
        }
    }

    private void setTextStyle(TextArea textArea) {
        textArea.setStyle(
                "-fx-font-size: "+ fontSize + "px;" +
                "-fx-text-fill: "+ fontColor + ";" +
                "-fx-font-family: "+ "\""+ fontFamily + "\" "+ ";");
    }

    private int getLine(int index, String text) {
        String[] lines = text.split("\n");
        int count = 0, lineIndex = 0;
        for (String line : lines) {
            lineIndex++;
            count += line.length() + 1;
            if (count > index) {
                return lineIndex;
            }
        }
        return -1;
    }

    private int getColumn(int index, String text, int lineStart) {
        String[] lines = text.split("\n");
        int count = 0, Index = 0;
        for (String line : lines) {
            Index++;
            if(Index<lineStart)
                count+=line.length()+1;
            else
                return index - count;
        }
        return -1;
    }
}