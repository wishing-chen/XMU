package task2;

public class Student {
    private String id;
    private String name;
    private String phoneNumber;
    private String email;
    private String imagePath;

    Student(String id,String name,String phoneNumber,String email,String imagePath)
    {
        this.id = id; this.name = name; this.phoneNumber = phoneNumber;
        this.email = email; this.imagePath = imagePath;
    }

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public String getEmail() {
        return email;
    }

    public String getImagePath() {
        return imagePath;
    }

    public void setId(String id) {
        this.id = id;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setImagePath(String imagePath) {
        this.imagePath = imagePath;
    }

    @Override
    public String toString() {
        return String.format("%s,%s,%s,%s,%s", id, name, phoneNumber, email, imagePath);
    }

    public static Student fromString(String str) {
        String[] parts = str.split(",");
        return new Student(parts[0], parts[1], parts[2], parts[3], parts[4]);
    }
}
