package task2;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.List;

public class Test extends Application {

    private TextField idField;
    private TextField nameField;
    private TextField phoneField;
    private TextField emailField;
    private ImageView imageView;
    private File selectedPhotoFile;
    private static final String OUTPUT_DIR = "D:\\java\\files\\lab11\\src\\main\\java\\task2\\output\\"; // 照片集中存放位置
    private static final String DATA_FILE = "D:\\java\\files\\lab11\\src\\main\\java\\task2\\students.txt"; // 学生信息保存位置

    private List<Student> students = new ArrayList<>();
    private int currentIndex = -1;

    @Override
    public void start(Stage primaryStage) {
        imageView = new ImageView(new Image("file:\\D:\\java\\files\\lab11\\src\\main\\java\\task2\\nothing.jpg"));
        imageView.setFitHeight(200);
        imageView.setFitWidth(200);

        idField = new TextField();
        nameField = new TextField();
        phoneField = new TextField();
        emailField = new TextField();
        Button photoButton = new Button("选择照片");
        Label photoLabel = new Label("未选择照片");
        Button addButton = new Button("新增");
        Button deleteButton = new Button("删除");
        Button updateButton = new Button("修改");
        Button queryButton = new Button("查询");
        Button prevButton = new Button("上一条");
        Button nextButton = new Button("下一条");

        // 选择
        photoButton.setOnAction(event -> {
            FileChooser fileChooser = new FileChooser();
            fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("JPG Files", "*.jpg"));
            selectedPhotoFile = fileChooser.showOpenDialog(primaryStage);
            if (selectedPhotoFile != null) {
                imageView.setImage(new Image("file:\\"+selectedPhotoFile.getAbsolutePath()));
                photoLabel.setText(selectedPhotoFile.getName());
            }
        });

        // 新增
        addButton.setOnAction(event -> {
            if (validateInput()) {
                try {
                    Student student = saveStudentInfo();
                    copyPhotoFile(student);
                    showAlert(Alert.AlertType.INFORMATION, "成功", "学生信息已保存");
                    loadStudents();
                    clearFields();
                } catch (IOException e) {
                    showAlert(Alert.AlertType.ERROR, "错误", "保存信息时发生错误：" + e.getMessage());
                }
            } else {
                showAlert(Alert.AlertType.WARNING, "输入错误", "请填写所有字段并选择照片");
            }
        });

        // 删除
        deleteButton.setOnAction(event -> {
            if (currentIndex >= 0 && currentIndex < students.size()) {
                students.remove(currentIndex);
                saveAllStudents();
                loadStudents();
                if (!students.isEmpty()) {
                    currentIndex = Math.min(currentIndex, students.size() - 1);
                    displayStudent(currentIndex);
                } else {
                    clearFields();
                }
            }
        });

        // 修改
        updateButton.setOnAction(event -> {
            if (currentIndex >= 0 && currentIndex < students.size()) {
                if (validateInput()) {
                    Student student = students.get(currentIndex);
                    student.setId(idField.getText());
                    student.setName(nameField.getText());
                    student.setPhoneNumber(phoneField.getText());
                    student.setEmail(emailField.getText());
                    if (selectedPhotoFile != null) {
                        student.setImagePath(selectedPhotoFile.getName());
                        try {
                            copyPhotoFile(student);
                        } catch (IOException e) {
                            showAlert(Alert.AlertType.ERROR, "错误", "保存照片时发生错误：" + e.getMessage());
                        }
                    }
                    saveAllStudents();
                    showAlert(Alert.AlertType.INFORMATION, "成功", "学生信息已修改");
                } else {
                    showAlert(Alert.AlertType.WARNING, "输入错误", "请填写所有字段并选择照片");
                }
            }
        });

        // 查询
        queryButton.setOnAction(event -> {
            String name = nameField.getText();
            if (!name.isEmpty()) {
                loadStudents();
                for (int i = 0; i < students.size(); i++) {
                    if (students.get(i).getName().equals(name)) {
                        currentIndex = i;
                        displayStudent(currentIndex);
                        break;
                    }
                }
            }
        });

        // 上一条
        prevButton.setOnAction(event -> {
            if (currentIndex > 0) {
                currentIndex--;
                displayStudent(currentIndex);
            }
        });

        // 下一条
        nextButton.setOnAction(event -> {
            if (currentIndex < students.size() - 1) {
                currentIndex++;
                displayStudent(currentIndex);
            }
        });

        // 布局
        GridPane grid = new GridPane();
        grid.setPadding(new Insets(10));
        grid.setHgap(10);
        grid.setVgap(10);

        grid.add(new Label("学号:"), 0, 0);
        grid.add(idField, 1, 0);
        grid.add(new Label("姓名:"), 0, 1);
        grid.add(nameField, 1, 1);
        grid.add(new Label("电话:"), 0, 2);
        grid.add(phoneField, 1, 2);
        grid.add(new Label("邮箱:"), 0, 3);
        grid.add(emailField, 1, 3);
        grid.add(photoButton, 0, 4);
        grid.add(photoLabel, 1, 4);
        grid.add(imageView,1,4);
        HBox buttonBox = new HBox(10, addButton, deleteButton, updateButton, queryButton, prevButton, nextButton);
        grid.add(buttonBox, 1, 5);

        Scene scene = new Scene(grid, 600, 400);
        primaryStage.setScene(scene);
        primaryStage.show();

        loadStudents();
    }

    private boolean validateInput() {
        return !idField.getText().isEmpty() &&
                !nameField.getText().isEmpty() &&
                !phoneField.getText().isEmpty() &&
                !emailField.getText().isEmpty();
    }

    private Student saveStudentInfo() throws IOException {
        Student student = new Student(idField.getText(), nameField.getText(), phoneField.getText(), emailField.getText(), selectedPhotoFile.getName());
        students.add(student);
        try (FileWriter writer = new FileWriter(DATA_FILE, true)) {
            writer.write(student.toString() + "\n");
        }
        return student;
    }

    private void copyPhotoFile(Student student) throws IOException {
        File outputDir = new File(OUTPUT_DIR);
        if (!outputDir.exists()) {
            outputDir.mkdirs();
        }
        File destFile = new File(outputDir, student.getImagePath());
        Files.copy(selectedPhotoFile.toPath(), destFile.toPath(), StandardCopyOption.REPLACE_EXISTING);
    }

    private void showAlert(Alert.AlertType alertType, String title, String message) {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    private void loadStudents() {
        students.clear();
        try (BufferedReader reader = new BufferedReader(new FileReader(DATA_FILE))) {
            String line;
            while ((line = reader.readLine()) != null) {
                students.add(Student.fromString(line));
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        if (!students.isEmpty()) {
            currentIndex = 0;
            displayStudent(currentIndex);
        } else {
            imageView.setImage(new Image("file:\\D:\\java\\files\\lab11\\src\\main\\java\\task2\\nothing.jpg"));
            clearFields();
        }
    }

    private void saveAllStudents() {
        try (FileWriter writer = new FileWriter(DATA_FILE)) {
            for (Student student : students) {
                writer.write(student.toString() + "\n");
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void displayStudent(int index) {
        if (index >= 0 && index < students.size()) {
            Student student = students.get(index);
            idField.setText(student.getId());
            nameField.setText(student.getName());
            phoneField.setText(student.getPhoneNumber());
            emailField.setText(student.getEmail());
            imageView.setImage(new Image("file:\\"+OUTPUT_DIR+student.getImagePath()));
            selectedPhotoFile = new File(OUTPUT_DIR, student.getImagePath());
        }
    }

    private void clearFields() {
        idField.clear();
        nameField.clear();
        phoneField.clear();
        emailField.clear();
        selectedPhotoFile = new File("file:\\D:\\java\\files\\lab11\\src\\main\\java\\task2\\nothing.jpg");
    }

    public static void main(String[] args) {
        launch(args);
    }
}