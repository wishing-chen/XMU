package task1;
import java.io.IOException;
import java.nio.file.*;
import java.nio.file.attribute.BasicFileAttributes;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.Scanner;

public class Test {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String path = scanner.nextLine();

        Path filePath = Paths.get(path);
        try {
            if (Files.exists(filePath)) {
                if (Files.isDirectory(filePath))
                    countFilesAndDirectories(filePath);
                else
                    printFileInfo(filePath);
            } else
                System.out.println("文件路径不存在");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static void countFilesAndDirectories(Path directory) throws IOException {
        final long[] fileCount = {0};
        final long[] directoryCount = {0};

        Files.walkFileTree(directory, new SimpleFileVisitor<>() {
            @Override
            public FileVisitResult preVisitDirectory(Path dir, BasicFileAttributes attrs) {
                if (dir.equals(directory)) {
                    return FileVisitResult.CONTINUE;
                }
                directoryCount[0]++;
                return FileVisitResult.CONTINUE;
            }

            @Override
            public FileVisitResult visitFile(Path file, BasicFileAttributes attrs) {
                fileCount[0]++;
                return FileVisitResult.CONTINUE;
            }
        });
        System.out.println("文件夹中包含的文件个数: " + Arrays.toString(fileCount));
        System.out.println("文件夹中包含的文件夹个数: " + Arrays.toString(directoryCount));
    }
    private static void printFileInfo(Path file) throws IOException {
        BasicFileAttributes attrs = Files.readAttributes(file, BasicFileAttributes.class);
        long fileSize = attrs.size();
        Date lastModifiedTime = new Date(attrs.lastModifiedTime().toMillis());

        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String lastModifiedDateString = sdf.format(lastModifiedTime);

        System.out.println("文件大小: " + fileSize + " 字节");
        System.out.println("最后修改日期: " + lastModifiedDateString);
    }
}
