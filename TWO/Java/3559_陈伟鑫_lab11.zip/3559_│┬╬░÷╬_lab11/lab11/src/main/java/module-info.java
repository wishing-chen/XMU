module lab11 {
    requires javafx.controls;
    requires javafx.fxml;

    opens task1 to javafx.fxml;
    exports task1;
    opens task2 to javafx.fxml;
    exports task2;
    opens task3 to javafx.fxml;
    exports task3;
}