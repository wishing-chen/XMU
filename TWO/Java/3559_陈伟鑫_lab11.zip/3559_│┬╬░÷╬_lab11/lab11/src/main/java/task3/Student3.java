package task3;

public class Student3 {
    private static final int ID_LENGTH = 10;
    private static final int NAME_LENGTH = 30;
    private static final int PHONE_LENGTH = 15;
    private static final int EMAIL_LENGTH = 30;
    private static final int IMAGE_PATH_LENGTH = 50;
    private static final int RECORD_LENGTH = ID_LENGTH + NAME_LENGTH + PHONE_LENGTH + EMAIL_LENGTH + IMAGE_PATH_LENGTH;

    private String id;
    private String name;
    private String phoneNumber;
    private String email;
    private String imagePath;

    public Student3(String id, String name, String phoneNumber, String email, String imagePath) {
        this.id = padRight(id, ID_LENGTH);
        this.name = padRight(name, NAME_LENGTH);
        this.phoneNumber = padRight(phoneNumber, PHONE_LENGTH);
        this.email = padRight(email, EMAIL_LENGTH);
        this.imagePath = padRight(imagePath, IMAGE_PATH_LENGTH);
    }

    private String padRight(String s, int n) {
        return String.format("%1$-" + n + "s", s);
    }

    public static Student3 fromString(String record) {
        String id = record.substring(0, ID_LENGTH).trim();
        String name = record.substring(ID_LENGTH, ID_LENGTH + NAME_LENGTH).trim();
        String phoneNumber = record.substring(ID_LENGTH + NAME_LENGTH, ID_LENGTH + NAME_LENGTH + PHONE_LENGTH).trim();
        String email = record.substring(ID_LENGTH + NAME_LENGTH + PHONE_LENGTH, ID_LENGTH + NAME_LENGTH + PHONE_LENGTH + EMAIL_LENGTH).trim();
        String imagePath = record.substring(ID_LENGTH + NAME_LENGTH + PHONE_LENGTH + EMAIL_LENGTH).trim();
        return new Student3(id, name, phoneNumber, email, imagePath);
    }

    public String getId() {
        return id;
    }

    public String getName() {
        return name.split(" ")[0];
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public String getEmail() {
        return email;
    }

    public String getImagePath() {
        return imagePath.split(" ")[0];
    }

    public void setId(String id) {
        this.id = id;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setImagePath(String imagePath) {
        this.imagePath = imagePath;
    }
    @Override
    public String toString() {
        return id + name + phoneNumber + email + imagePath;
    }

    public static int getRecordLength() {
        return RECORD_LENGTH;
    }
}
