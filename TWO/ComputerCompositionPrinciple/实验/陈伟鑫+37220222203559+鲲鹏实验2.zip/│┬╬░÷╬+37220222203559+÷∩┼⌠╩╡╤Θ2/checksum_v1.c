#include <stdio.h>
#include <stdlib.h>
#include <time.h>
short checksum_v1(short* data)
{
        short i;
        short sum = 0;
        for(i = 0;i<64;i++)
                sum+=data[i];
        return sum;
}
int main(){
        short total;
        short arr[64]={1};
        struct timespec t1,t2;
        int i=0;
        clock_gettime(CLOCK_MONOTONIC,&t1);

        for(;i<1000000;i++)
                total=checksum_v1(arr);
        clock_gettime(CLOCK_MONOTONIC,&t2);
        printf("Time is %11u ns\n",t2.tv_nsec-t1.tv_nsec);
        return 0;
}