#include <stdio.h>

struct struct_v1
{
        char a;
        int b;
        char c;
        short d;
};
struct struct_v2
{
        char a;
        char c;
        short d;
        int b;
};
void test(struct struct_v1 str1,struct struct_v2 str2)
{
        str2.a=str1.a;
        str2.b=str1.b;
        str2.c=str1.c;
        str2.d=str1.d;
}
int main()
{
        struct struct_v1 str1 = {0x11,0x22334455,0x66,0x7788};
        struct struct_v2 str2 = {0,0,0,0};
        test(str1,str2);
        return 0;
}