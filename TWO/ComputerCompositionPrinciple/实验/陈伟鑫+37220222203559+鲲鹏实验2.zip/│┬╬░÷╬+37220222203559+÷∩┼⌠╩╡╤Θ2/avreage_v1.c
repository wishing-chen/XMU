#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int average_v1(int a,int b)
{
        return (a+b)/2;
}
int main(){
        struct timespec t1,t2;
        int i=0;
        int a=1;
        int b=1;
        int total;
        clock_gettime(CLOCK_MONOTONIC,&t1);
        for(;i<1000000;i++)
        {
                total = average_v1(a,b);
                total = average_v1(a,b);
                total = average_v1(a,b);
                total = average_v1(a,b);
        }
        clock_gettime(CLOCK_MONOTONIC,&t2);
        printf("Time is %11u ns\n",t2.tv_nsec-t1.tv_nsec);
        return 0;
}