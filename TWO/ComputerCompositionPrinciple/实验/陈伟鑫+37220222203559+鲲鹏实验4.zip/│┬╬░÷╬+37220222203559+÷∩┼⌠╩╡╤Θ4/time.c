#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#define LEN 60000000
char src[LEN], dst[LEN];
long int len = LEN;
extern void memorycopy(char *dst, char *src, long int len1);
int main()
{
    struct timespec t1, t2;
    int i;
    for (i = 0; i < LEN - 1; i++)
    {
        src[i] = 'a';
    }
    src[i] = 0;
    clock_gettime(CLOCK_MONOTONIC, &t1);
    memorycopy(dst, src, len);
    clock_gettime(CLOCK_MONOTONIC, &t2);
    printf("Mempry copy time is %11u ns\n", t2.tv_sec - t1.tv_sec);
    return 0;
}