// 矩阵相乘函数
static void matrix_mul_asm(uint8_t ** matrix_A, uint8_t ** matrix_B, uint8_t ** matrix_C)
{
    uint8_t *a = (uint8_t *)matrix_A;
    uint8_t *b = (uint8_t *)matrix_B;
    uint8_t *c = (uint8_t *)matrix_C;
    // 内嵌汇编代码
    __asm__ volatile (
        // 将matrix_A矩阵的四行分组加载到v0到v3寄存器的低64位中
        "ld4 {v0.8b-v3.8b}, [%0]\n"
        // 将matrix_B矩阵的四列分组加载到v4到v7寄存器的低64位中
        "ld4 {v4.8b-v7.8b}, [%1]\n"
        
        // 每行依次进行乘法计算
        // 最后的矩阵相乘结果放在v0到v3的低64位中
        "smlal v0.8h, v4.8b, v0.8b\n"
        "smlal v1.8h, v5.8b, v1.8b\n"
        "smlal v2.8h, v6.8b, v2.8b\n"
        "smlal v3.8h, v7.8b, v3.8b\n"
        
        // 将计算结果存储到矩阵matrix_C中
        "st4 {v0.8b-v3.8b}, [%2]\n"
        // +表示存放在寄存器中, 可读可写
        : "+r"(a), "+r"(b), "+r"(c)
        : 
        : "cc", "memory", "v0", "v1", "v2", "v3", "v4", "v5", "v6", "v7"
    );
}
