#include <iostream>
#include <chrono>
#include <random>
#define KB 1024
#define MB 1048576
#define read_time 100000000
using namespace std;
using std::chrono::high_resolution_clock;
using std::chrono::duration;
using std::chrono::duration_cast;
random_device rd;
mt19937 gen(rd());
void read_speed(int size)
{
    int n = size;
    char *buffer = new char[n];
    fill(buffer, buffer + n, 1);
    uniform_int_distribution<> dis(0, n - 1);
    vector<int> random_index;
    for (int i = 0; i < read_time; i++)
    {
        int index = dis(gen);
        random_index.push_back(index);
    }
    int sum = 0;
    high_resolution_clock::time_point t1, t2;
    t1 = high_resolution_clock::now();
    for (int i = 0; i < read_time; i++)
    {
        sum += buffer[random_index[i]];
    }
    t2 = high_resolution_clock::now();
    duration<double> time_span = duration_cast<duration<double>>(t2 - t1);
    double dt = time_span.count();
    if(size < 1048576)
    {
        cout << (size / 1024) << "KB: " << "访问次数：" << sum;
        cout << "读吞吐量" << ((double)sum / 1024.0) / dt << endl;
    }
    else
    {
        cout << (size / 1048576) << "MB: " << "访问次数：" << sum;
        cout << "读吞吐量" << ((double)sum / 1024.0) / dt << endl;
    }
    delete[] buffer;
}
int main()
{
    int size = 2 * KB;
    for(int i = 0; i < 16; i++)
    {
        size = size * 2;
        read_speed(size);
    }
    return 0;
}