#include <iostream>
#include <chrono>
#include <cstring>

#define KB 1024
#define MB 1048576

using namespace std;
using std::chrono::high_resolution_clock;
using std::chrono::duration;
using std::chrono::duration_cast;

void stride_access(char* buffer, int size, int stride) {
    int sum = 0;
    int n = size;

    // 记录开始时间
    high_resolution_clock::time_point t1 = high_resolution_clock::now();

    // 双层循环遍历内存块，步长不同
    for (int j = 0; j < stride; j++) {
        for (int i = 0; i < n; i += stride) {
            sum += buffer[i];  // 进行有意义的访存
        }
    }

    // 记录结束时间
    high_resolution_clock::time_point t2 = high_resolution_clock::now();

    // 记录时间差
    duration<double> time_span = duration_cast<duration<double>>(t2 - t1);

    double dt = time_span.count();
    cout << "stride = " << stride << " 访问次数: " << sum << endl;
    cout << "平均吞吐量: " << ((double)sum / 1024.0) / dt << " KB/s" << endl;
}

int main() {
    int size = 64 * MB;  // 设置数据块长度为64MB
    char *buffer = new char[size];  // 申请内存块
    memset(buffer, 1, size);  // 填充数据

    int stride = 1;  // 初始步长为1
    for (stride = 1; stride <= 512; stride *= 2) {  // 每次调用后步长翻倍
        stride_access(buffer, size, stride);  // 调用该函数计算计数
    }

    delete[] buffer;  // 释放内存
    return 0;
}
