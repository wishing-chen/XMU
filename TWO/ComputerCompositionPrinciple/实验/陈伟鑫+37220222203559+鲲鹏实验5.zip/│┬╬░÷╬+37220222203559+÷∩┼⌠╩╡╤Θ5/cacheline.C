#include <iostream>
#include <chrono>
#include <random>
#define KB 1024
#define MB 1048576
using namespace std;
using std::chrono::high_resolution_clock;
using std::chrono::duration;
using std::chrono::duration_cast;
void stride_access(char *buffer, int stride)
{
    int n = 200 * MB;
    int sum = 0;
    high_resolution_clock::time_point t1, t2;
    t1 = high_resolution_clock::now();
    for(int j = 0; j< stride; j++)
    {
        for (int i = 0; i < n; i += stride)
        {
            sum += buffer[i];
        }
    }
    t2 = high_resolution_clock::now();
    duration<double> time_span = duration_cast<duration<double>>(t2 - t1);
    double dt = time_span.count();
    cout << stride << "访问次数：" << sum;
    cout << "平均吞吐量" << (((double)sum / 1024.0) / dt)<< endl;
}
int main()
{
    int size = 200 * MB;
    char *buffer = new char[size];
    fill(buffer, buffer + size, 1);
    int stride = 1;
    for(;stride < 1024;)
    {
        stride_access(buffer, stride);
        stride = stride * 2;
    }
    return 0;
}