#include <stdio.h>
extern int add(int sum);
int main()
{
  int val;
  printf("input a positive integer:");
  scanf("%d",&val);
__asm__ volatile(
  "MOV x1,#0\n"
  "add:\n"
  "ADD x1,x1,x0\n"
  "SUB x0,x0,#1\n"
  "CMP x0,#0\n"
  "BNE add\n"
  "MOV x0,x1\n"
  :"=r" (val)
  :"0" (val)
  :
  );
  printf("sum=%d\n",val);
  return 0;
}